'use strict';
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../outputs');
http.createServer((req,res)=>{
  const requested=new URL(req.url,'http://127.0.0.1:18742').pathname;
  if(requested==='/favicon.ico'){res.writeHead(204);res.end();return;}
  if(requested!=='/'&&requested!=='/axolotl-four-seasons.html'){res.writeHead(404);res.end('Not found');return;}
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
  res.end(fs.readFileSync(path.join(root,'axolotl-four-seasons.html')));
}).listen(18742,'127.0.0.1',()=>process.stdout.write('Preview ready: http://127.0.0.1:18742/axolotl-four-seasons.html\n'));
