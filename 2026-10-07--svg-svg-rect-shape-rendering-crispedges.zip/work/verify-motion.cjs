'use strict';
// Runs the original animation logic with a tiny purpose-written DOM stand-in.
// Real visual and interaction verification is done separately in the browser.
const fs=require('node:fs');
const vm=require('node:vm');
const html=fs.readFileSync('outputs/axolotl-four-seasons.html','utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
class Element {
 constructor(id=''){this.id=id;this.dataset={};this.style={};this.attributes={};this.children=[];this.listeners={};this._html='';this.textContent='';this.hidden=false;}
 set innerHTML(v){this._html=v;this.children=[];}
 get innerHTML(){return this._html;}
 setAttribute(k,v){this.attributes[k]=String(v);}
 getAttribute(k){return this.attributes[k]??null;}
 addEventListener(k,fn){this.listeners[k]=fn;}
 appendChild(el){el.parent=this;this.children.push(el);}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(el=>el!==this);}
}
class Input extends Element {}
class Textarea extends Element {}
class Button extends Element {}
function boot(seed){
 const elements=new Map([...html.matchAll(/\bid="([^"]+)"/g)].map(m=>[m[1],new Element(m[1])]));
 const buttons=['spring','summer','autumn','winter'].map(key=>{const b=new Button();b.dataset.season=key;return b;});
 const handlers={},caption=new Element(),doc={hidden:false,getElementById:id=>elements.get(id),querySelector:()=>caption,querySelectorAll:()=>buttons,createElementNS:()=>new Element(),addEventListener:(k,fn)=>{handlers[k]=fn;}};
 let frame=null,stamp=1000,randomSeed=seed;
 const math=Object.create(Math);math.random=()=>{randomSeed=(randomSeed*1664525+1013904223)>>>0;return randomSeed/4294967296;};
 const sandbox={document:doc,window:{},Math:math,HTMLInputElement:Input,HTMLTextAreaElement:Textarea,HTMLButtonElement:Button,matchMedia:()=>({matches:false,addEventListener:()=>{}}),requestAnimationFrame:fn=>{frame=fn;}};
 const context=vm.createContext(sandbox);new vm.Script(script).runInContext(context);
 const step=dt=>{stamp+=dt*1000;frame(stamp);};step(.01);
 return {state:()=>sandbox.window.SeasonRide.getState(),step,elements,buttons,handlers};
}
const results=[];
for(const season of ['spring','summer','autumn','winter'])for(const speed of [180,235,300])for(const manual of [false,true]){
 const app=boot(982713+results.length*8191);app.buttons.find(b=>b.dataset.season===season).listeners.click();app.elements.get('speed').listeners.input({target:{value:speed}});
 let maxHeight=0,maxCollision=0,kinds=new Set();
 for(let frame=0;frame<2400;frame++){
  if(manual&&frame%67===13)app.elements.get('jumpButton').listeners.click();
  app.step(.05);const s=app.state();maxHeight=Math.max(maxHeight,s.height);maxCollision=Math.max(maxCollision,s.collisions);s.obstacles.forEach(o=>kinds.add(o.kind));
 }
 const s=app.state();results.push({season,speed,manual,seconds:Math.round(s.time),cleared:s.cleared,autoJumps:s.autoJumps,manualJumps:s.manualJumps,collisions:maxCollision,maxHeight:Math.round(maxHeight*100)/100,obstacleKinds:[...kinds].sort()});
}
const extra=boot(378167);
extra.elements.get('pauseButton').listeners.click();const pausedBefore=extra.state();for(let i=0;i<30;i++)extra.step(.05);const pausedAfter=extra.state();
const pauseVerified=pausedBefore.time===pausedAfter.time&&pausedBefore.frames===pausedAfter.frames;
extra.buttons[3].listeners.click();const pausedSwitchVerified=extra.state().paused&&extra.state().season==='winter';extra.elements.get('pauseButton').listeners.click();extra.step(.05);const resumeVerified=extra.state().time>pausedBefore.time;
extra.handlers.keydown({code:'ArrowRight',target:new Element(),preventDefault:()=>{}});const keyboardSwitchVerified=extra.state().season==='spring';
const report={scenarios:results.length,simulatedSeconds:results.reduce((v,r)=>v+r.seconds,0),obstaclesCleared:results.reduce((v,r)=>v+r.cleared,0),allPassed:results.every(r=>r.collisions===0&&r.cleared>10&&r.obstacleKinds.length===3&&r.maxHeight<155)&&pauseVerified&&pausedSwitchVerified&&resumeVerified&&keyboardSwitchVerified,pauseVerified,pausedSwitchVerified,resumeVerified,keyboardSwitchVerified,results};
fs.writeFileSync('work/motion-verification.json',JSON.stringify(report,null,2));
process.stdout.write(JSON.stringify({...report,results:undefined},null,2)+'\n');
if(!report.allPassed){process.stdout.write(JSON.stringify(results.filter(r=>r.collisions||r.maxHeight>=155),null,2)+'\n');process.exitCode=1;}
