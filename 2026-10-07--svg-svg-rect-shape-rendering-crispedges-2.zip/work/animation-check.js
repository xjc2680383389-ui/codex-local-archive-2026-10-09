
(() => {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const $ = id => document.getElementById(id);
  const el = (name, attrs = {}, parent) => {
    const n = document.createElementNS(NS, name);
    for (const [key, value] of Object.entries(attrs)) n.setAttribute(key, String(value));
    if (parent) parent.appendChild(n);
    return n;
  };
  const rect = (parent,x,y,width,height,fill,extra={}) => el('rect',{x,y,width,height,fill,...extra},parent);
  const path = (parent,d,fill,extra={}) => el('path',{d,fill,...extra},parent);
  const circle = (parent,cx,cy,r,fill,extra={}) => el('circle',{cx,cy,r,fill,...extra},parent);
  const use = (parent,id,x,y,scale=1,extra={}) => el('use',{href:'#'+id,transform:`translate(${x} ${y}) scale(${scale})`,...extra},parent);
  const palettes = {
    spring:{index:'01',en:'SPRING',name:'春日',title:'风经过鲜花平原',note:'把好心情，装进春天的风里。',caption:'沿途的每一个小障碍，都值得轻轻一跃。',sky:['#cce9df','#f1f1d2'],road:['#eedfbc','#e5cfa8'],verge:'#aac889',edge:'#ecedca',sun:'#fff2b6',far:'#b8d6a6',near:'#8cb994',speck:'#c8ad83'},
    summer:{index:'02',en:'SUMMER',name:'盛夏',title:'穿过金色的遗迹',note:'金字塔不说话，沙漠替它讲故事。',caption:'让热风带路，去听古老沙海的回声。',sky:['#f5dba4','#fff0cd'],road:['#e7bd7d','#dca769'],verge:'#edcc8c',edge:'#f8e1a5',sun:'#ffe6a0',far:'#d7b780',near:'#deb276',speck:'#bf905b'},
    autumn:{index:'03',en:'AUTUMN',name:'金秋',title:'路过落叶的城市',note:'拐过街角，就撞见一整个秋天。',caption:'车铃、落叶、街角，是城市写来的秋日明信片。',sky:['#dbe2d7','#f7e9cb'],road:['#9da79b','#8d9b91'],verge:'#d3b979',edge:'#efe1bb',sun:'#f8d48d',far:'#afc1b4',near:'#a6ae8f',speck:'#727f76'},
    winter:{index:'04',en:'WINTER',name:'冬雪',title:'向雪山寄一封信',note:'车轮轻轻转，世界慢慢白。',caption:'就算世界结了冰，好奇心也会暖暖地向前。',sky:['#c5e1e8','#edf4e9'],road:['#c5e0e0','#a9cccf'],verge:'#edf3e5',edge:'#fffdf3',sun:'#ffefd0',far:'#abc9d1',near:'#a2c5c6',speck:'#85b0b8'}
  };
  const state = {season:'spring',time:0,distance:0,jumps:0,paused:matchMedia('(prefers-reduced-motion: reduce)').matches,speed:1,travel:0,nextSpawn:950,jumpTime:-1,pose:0,land:0,obstacles:[],particles:[],frames:0,cleared:0,collisions:0,minClearance:Infinity};
  const W=1600, ACTOR=570, BASE=628, SPEED=265, FLIGHT=2.8, HEIGHT=150;
  let last=0, hudTime=0, spin=0, scenery=[], weather=[];
  function rng(seed){return ()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}
  function tileLayer(id,draw,speed){
    const root=$(id);root.replaceChildren();
    const content=el('g',{id:id+'-tile'},root);draw(content);
    use(root,id+'-tile',W,0);use(root,id+'-tile',-W,0);
    scenery.push({node:root,speed});
  }
  function cloudLayer(){
    const root=$('clouds');root.replaceChildren();
    for(let i=0;i<6;i++)use(root,'cloud-shape',i*285+35,72+(i%3)*49,.55+(i%3)*.28,{opacity:.5+(i%2)*.3});
  }
  function hill(parent,color,y,offset){path(parent,`M0 ${y}Q200 ${y-110+offset} 400 ${y}T800 ${y}T1200 ${y}T1600 ${y}V650H0Z`,color);}
  function tree(parent,x,y,scale,season){
    const g=el('g',{transform:`translate(${x} ${y}) scale(${scale})`},parent);
    const autumn=season==='autumn';
    path(g,'M-5 0L-3-92H6L9 0Z',autumn?'#8e7454':'#78905f');
    path(g,'M0-44L-31-72M3-57L29-81','none',{stroke:autumn?'#8e7454':'#78905f','stroke-width':6,'stroke-linecap':'round'});
    const colors=autumn?['#df9d55','#e9af62','#d57d49']:['#8cb979','#9ac581','#73a572'];
    circle(g,-27,-95,35,colors[0]);circle(g,22,-104,38,colors[1]);circle(g,0,-130,34,colors[1]);circle(g,0,-85,36,colors[0]);circle(g,-26,-102,20,colors[1],{opacity:.4});
    path(g,'M-9-115Q-3-111 3-116M18-87L26-91','none',{stroke:colors[2],'stroke-width':3,'stroke-linecap':'round'});
  }
  function pine(parent,x,y,scale){
    const g=el('g',{transform:`translate(${x} ${y}) scale(${scale})`},parent);
    rect(g,-5,-70,10,70,'#7b9690',{rx:3});
    path(g,'M0-156L-45-80H-29L-60-29Q0-5 60-29L29-80H45Z','#85aaa4',{'stroke-linejoin':'round'});
    path(g,'M0-156L-36-94Q-14-87 0-99Q16-88 36-94Z','#fffdf1');
    path(g,'M-26-72L-47-37Q-22-30 0-42Q21-29 47-37L27-72Q14-63 0-72Q-15-62-26-72Z','#f5f8ea');
  }
  function cactus(parent,x,y,scale){
    const g=el('g',{transform:`translate(${x} ${y}) scale(${scale})`,stroke:'#799478','stroke-width':16,'stroke-linecap':'round',fill:'none'},parent);
    path(g,'M0 0V-91M0-38H-23Q-29-38-29-48V-61M0-56H24Q30-56 30-65V-79','none');
    path(g,'M-2-9V-88','none',{stroke:'#a2b18b','stroke-width':3});
  }
  function makeScenery(){
    scenery=[];const s=state.season,p=palettes[s];
    $('sky-top').setAttribute('stop-color',p.sky[0]);$('sky-bottom').setAttribute('stop-color',p.sky[1]);
    $('road-top').setAttribute('stop-color',p.road[0]);$('road-bottom').setAttribute('stop-color',p.road[1]);
    $('verge').setAttribute('fill',p.verge);$('road-edge').setAttribute('fill',p.edge);$('sun').children[1].setAttribute('fill',p.sun);
    cloudLayer();
    tileLayer('distant',g=>{
      if(s==='spring'){
        hill(g,'#cadbb3',460,5);hill(g,'#b8d2a7',491,42);
        for(const x of [165,880,1310]){const birds=el('g',{transform:`translate(${x} 207)`,fill:'none',stroke:'#87aa8e','stroke-width':2.5,'stroke-linecap':'round'},g);path(birds,'M0 0Q7-8 14 0Q21-8 28 0M39 20Q45 14 51 20Q57 14 63 20','none');}
      }else if(s==='summer'){
        hill(g,'#ecd19a',458,55);
        const pyramid=(x,y,w,h)=>{const group=el('g',{},g);path(group,`M${x-w/2} ${y}L${x} ${y-h}L${x+w/2} ${y}Z`,'#dfb477');path(group,`M${x} ${y-h}L${x+w/2} ${y}H${x+22}Z`,'#c69a65');path(group,`M${x-w*.18} ${y-h*.37}H${x+9}M${x-w*.29} ${y-h*.16}H${x+15}M${x-w*.07} ${y-h*.64}H${x+5}`,'none',{stroke:'#c99e69','stroke-width':3,opacity:.6});};
        pyramid(195,508,390,260);pyramid(1090,510,410,285);pyramid(1455,493,245,169);
        path(g,'M0 514Q400 453 800 514T1600 514V610H0Z','#e5c087');
        for(const x of [900,1340]){rect(g,x,425,18,93,'#be9c6e',{rx:4});rect(g,x-4,421,26,12,'#cfaa76',{rx:3});rect(g,x+58,446,18,72,'#c6a374',{rx:3});rect(g,x+52,439,30,12,'#d1ad7a',{rx:3});path(g,`M${x+9} 457H${x+68}`,'none',{stroke:'#c6a374','stroke-width':9});}
      }else if(s==='autumn'){
        const r=rng(305);
        for(let x=-50;x<W;x+=96){const h=100+r()*160;rect(g,x,490-h,82,h,'#b4c4b7',{rx:8});rect(g,x+30,477-h,20,16,'#b4c4b7',{rx:3});for(let yy=515-h;yy<465;yy+=30)for(let xx=x+12;xx<x+73;xx+=23)rect(g,xx,yy,10,14,'#d8dcca',{rx:2});}
        path(g,'M0 483H1600V570H0Z','#b6c2a4');
      }else{
        path(g,'M-160 535L124 233L364 490L594 258L824 494L1082 182L1371 483L1515 304L1752 550Z','#a8c9d1');
        path(g,'M124 233L-1 366L88 342L125 375L161 349L235 375ZM594 258L503 364L563 347L594 375L623 351L690 367ZM1082 182L938 342L1029 312L1081 351L1122 307L1230 352ZM1515 304L1451 378L1500 361L1526 385L1550 365L1591 389Z','#fffdf1');
        path(g,'M124 235L364 490L137 428L171 355ZM594 260L824 494L628 434L623 351ZM1082 185L1371 483L1116 420L1122 307Z','#91b8c4', {opacity:.7});
        hill(g,'#d5e8e3',537,39);
      }
    },.13);
    tileLayer('middle',g=>{
      if(s==='spring'){
        hill(g,'#94bd8f',548,49);for(const [x,y,z] of [[90,542,.78],[1000,542,.74],[1450,550,.91]])tree(g,x,y,z,s);
        const mill=el('g',{transform:'translate(1270 434)',stroke:'#879e76','stroke-width':3,'stroke-linejoin':'round'},g);
        path(mill,'M-18 91L-12 7H15L24 91Z','#eee9c9');path(mill,'M-22 8L1-16L25 8Z','#be9b73');circle(mill,0,26,5,'#7c926c');path(mill,'M-3 23L-42-10L-49-3L-9 30M3 20L36-18L43-11L9 29M5 32L43 66L50 59L11 25M-5 32L-39 70L-46 63L-10 26','#f9f2d6');
      }else if(s==='summer'){
        hill(g,'#e6c082',554,54);path(g,'M0 563Q400 496 800 563T1600 563V620H0Z','#eac68d');
        cactus(g,141,555,.72);cactus(g,1320,566,.8);cactus(g,899,551,.5);
        path(g,'M1140 540h95v18h-95Z','#d0a572');rect(g,1155,497,43,43,'#d7ae77',{rx:7});path(g,'M1165 509H1186M1165 520H1186','none',{stroke:'#b79365','stroke-width':3});
      }else if(s==='autumn'){
        const r=rng(82);for(let x=0;x<W;x+=205){let h=117+r()*80;const c=['#d5bd94','#c9b58a','#b7b599'][Math.floor(r()*3)];rect(g,x+8,548-h,169,h,c,{rx:5});path(g,`M${x+1} ${548-h}L${x+23} ${528-h}H${x+150}L${x+184} ${548-h}Z`,'#8e9c84');for(let yy=565-h;yy<506;yy+=33)for(let xx=x+23;xx<x+155;xx+=32){rect(g,xx,yy,17,23,'#edf0d7',{rx:3});path(g,`M${xx+8} ${yy}V${yy+23}`,'none',{stroke:'#acae89','stroke-width':2});}rect(g,x+70,509,35,39,'#839c8c',{rx:14});}
        rect(g,0,548,W,20,'#c3b88e');
        for(const x of [83,410,1000,1430])tree(g,x,576,.84,s);
        for(const x of [270,1270]){path(g,`M${x} 571V437Q${x} 419 ${x+18} 419H${x+31}`,'none',{stroke:'#647e70','stroke-width':5,'stroke-linecap':'round'});path(g,`M${x+18} 427Q${x+25} 406 ${x+40} 426Z`,'#6d8677');circle(g,x+30,428,5,'#f9e6ae');}
      }else{
        hill(g,'#e0ece3',550,34);for(const [x,z] of [[25,.8],[198,1],[900,.67],[1070,.93],[1400,.9],[1510,.7]])pine(g,x,565,z);
        const cabin=el('g',{transform:'translate(1227 483)'},g);rect(cabin,-35,-1,69,49,'#ac9d87',{rx:3});path(cabin,'M-49 4L-4-41L47 4Z','#829e98');path(cabin,'M-49 4L-4-41L47 4L24-4L-4-25L-29-2Z','#fffdf3');rect(cabin,-14,16,22,22,'#f0d393',{rx:3});rect(cabin,21,-38,11,23,'#9a9d8b',{rx:2});
      }
    },.32);
    tileLayer('roadside',g=>{
      const r=rng(471);for(let i=0;i<45;i++){const x=r()*W,y=580+r()*38;
        if(s==='spring'){use(g,'flower-shape',x,y,.4+r()*.45,{color:['#e89c98','#faf3ca','#d9b770'][i%3]});}
        else if(s==='summer'){path(g,`M${x-6} ${y}Q${x} ${y-8} ${x+9} ${y}Z`,'#cfaa72');if(i%8===0)cactus(g,x,y,.23);}
        else if(s==='autumn'){use(g,'leaf-shape',x,y,.5+r()*.6,{color:['#c88546','#e6b460','#e1a06b'][i%3]});}
        else{path(g,`M${x-12} ${y}Q${x} ${y-8} ${x+19} ${y}`,'none',{stroke:'#fffdf4','stroke-width':4,'stroke-linecap':'round'});}
      }
      if(s==='spring'){path(g,'M170 610V566M267 610V564M160 578H280M159 594H280','none',{stroke:'#d9d7ad','stroke-width':7,'stroke-linecap':'round'});}
    },.7);
    tileLayer('road-marks',g=>{
      const r=rng(570);for(let i=0;i<35;i++){const x=r()*W,y=672+r()*78;path(g,`M${x} ${y}h${8+r()*26}`,'none',{stroke:p.speck,'stroke-width':2.5,'stroke-linecap':'round',opacity:.38});}
      for(let x=0;x<W;x+=160)path(g,`M${x} 733h72`,'none',{stroke:s==='autumn'?'#ece1b7':'#fff3d1','stroke-width':4,'stroke-linecap':'round',opacity:s==='winter'?.4:.65});
      if(s==='winter')for(let x=70;x<W;x+=330)path(g,`M${x} 690l25 6l-9 13m9-13l31-6`,'none',{stroke:'#7faeb8','stroke-width':2,opacity:.35});
    },1);
    tileLayer('foreground',g=>{
      const r=rng(800);for(let i=0;i<15;i++){const x=r()*W,y=765+r()*28;
        if(s==='spring')use(g,'flower-shape',x,y,.9,{color:['#e4a2a3','#f8eac3','#d9bc69'][i%3],opacity:.85});
        else if(s==='autumn')use(g,'leaf-shape',x,y,1.25,{color:['#cf9956','#edbc66'][i%2],opacity:.8});
        else if(s==='winter')path(g,`M${x-55} ${y}Q${x} ${y-17} ${x+54} ${y}Z`,'#eef4e7');
        else path(g,`M${x-26} ${y}Q${x} ${y-7} ${x+31} ${y}`,'none',{stroke:'#edcb8c','stroke-width':4,'stroke-linecap':'round'});
      }
    },1.12);
    const wr=$('weather');wr.replaceChildren();weather=[];const r=rng(23);
    for(let i=0;i<(s==='winter'?35:s==='summer'?7:16);i++){
      const g=el('g',{opacity:s==='summer'?.24:.68},wr);
      if(s==='spring')path(g,'M-4 0Q-1-7 5-3Q7 3 1 5Z',['#edb5b2','#fff6d8'][i%2]);
      else if(s==='autumn')use(g,'leaf-shape',0,0,.4,{color:['#cf8c4a','#dda448','#c67d4c'][i%3]});
      else if(s==='winter')use(g,'snowflake-shape',0,0,.45+r()*.6);
      else path(g,'M0 0H32','none',{stroke:'#fff8df','stroke-width':2,'stroke-linecap':'round'});
      weather.push({node:g,x:r()*1540,y:r()*690,phase:r()*6,speed:14+r()*19});
    }
    $('chapter').textContent=p.index+' / '+p.en;$('place').textContent=p.title;$('place-note').textContent=p.note;$('scene-caption').textContent=p.caption;
    $('world-title').textContent='美西螈与机械鹈鹕的'+p.name+'骑行';
    $('season-panel').setAttribute('aria-labelledby','tab-'+s);
  }
  // All axolotl shapes, including animated limbs, are individual square pixels.
  const PIX=7, pink='#f4b0b9', light='#ffd3ce', shade='#d6859a', dark='#ac586e', gill='#e681a2';
  function pixelArt(parent,rows,x,y,size,colors){
    rows.forEach((row,iy)=>[...row].forEach((c,ix)=>{if(colors[c])rect(parent,x+ix*size,y+iy*size,size,size,colors[c]);}));
  }
  pixelArt($('axolotl-tail'),[
    '..dd..............',
    '.dppd.............',
    'dlpppd............',
    'dlppppd...........',
    '.dlppppdd.........',
    '..dlpppppdddd.....',
    '...dllpppppppddd..',
    '....dddlllppppppdd',
    '.......ddddllllppd',
    '...........ddddddd'
  ],-220,-369,7,{d:shade,p:pink,l:light});
  pixelArt($('rider-body'),[
    '....dddd...',
    '...dllllld.',
    '..dllllllld',
    '..dppppllld',
    '..dppppplld',
    '..dppppplld',
    '..dppppplld',
    '..dppppplld',
    '.dpppppllld',
    '.dppppplld.',
    '.dddddddd..'
  ],-137,-383,7,{d:shade,p:pink,l:light});
  pixelArt($('axolotl-head'),[
    '..gg.....................gg..',
    '.ggGg...................gGgg.',
    '..gGGg.................gGGg..',
    '...gGGg...ddddddddd...gGGg...',
    'gg..gGGg.ddpppppppppdd.gGGg.gg',
    'gGgg.gGGdppplllllllpppdGGg.ggGg',
    '.gGGggGdppplllllllllpppdGggGGg.',
    '..ggGGGdpplllllllllllppdGGGgg..',
    '....ggGdppllElllllEllppdGgg....',
    '..ggGGGdppllElllllEllppdGGGgg..',
    '.gGGg.GdpplrlllllllrllpdG.gGGg.',
    'gGGg..GdpplrrlllllrrllpdG..gGGg',
    '.gg...GdppllllllllllllpdG...gg.',
    '.......dppplllllllllpppd.......',
    '........ddppplllllpppdd........',
    '..........ddddddddddd..........'
  ],-200,-485,6,{d:shade,p:pink,l:light,g:dark,G:gill,E:'#3a4846',r:'#e98e9d'});
  // Place the broad, six-gilled face above the shoulders.
  $('axolotl-head').setAttribute('transform','translate(21 17)');
  for(const [x,y] of [[-122,-419],[-104,-419],[-116,-413],[-110,-413]])rect($('axolotl-head'),x,y,6,6,'#3a4846');
  const limbPixels={};
  function pixelLimb(id,points,color,thick=2){
    const parent=$(id);let list=limbPixels[id];
    if(!list){list=[];for(let i=0;i<90;i++)list.push(rect(parent,0,0,PIX,PIX,color));limbPixels[id]=list;}
    const cells=new Set();
    for(let s=0;s<points.length-1;s++){
      const ax=Math.round(points[s][0]/PIX),ay=Math.round(points[s][1]/PIX),bx=Math.round(points[s+1][0]/PIX),by=Math.round(points[s+1][1]/PIX);
      const steps=Math.max(Math.abs(bx-ax),Math.abs(by-ay),1);
      for(let i=0;i<=steps;i++){const x=Math.round(ax+(bx-ax)*i/steps),y=Math.round(ay+(by-ay)*i/steps);for(let k=0;k<thick;k++)cells.add(x+','+(y+k));}
    }
    let i=0;for(const cell of cells){if(i===list.length)list.push(rect(parent,0,0,PIX,PIX,color));const [x,y]=cell.split(',').map(Number);list[i].setAttribute('x',x*PIX);list[i].setAttribute('y',y*PIX);list[i].setAttribute('fill',color);list[i].setAttribute('visibility','visible');i++;}
    for(;i<list.length;i++)list[i].setAttribute('visibility','hidden');
  }
  function rider(t,j){
    const pedal=t*6.1,px=-34+Math.cos(pedal)*23,py=-247+Math.sin(pedal)*23;
    const pose=state.pose;
    if(j>0){
      pixelLimb('far-leg',[[-102,-320],[-60,-305],[-35,-276]],shade,2);
      pixelLimb('near-leg',[[-108,-319],[-57,-324+10*j],[-15,-291-7*j]],pink,2);
      if(pose===1)pixelLimb('rider-arm',[[-73,-365],[-29,-377],[2,-413]],pink,2);
      else if(pose===2)pixelLimb('rider-arm',[[-73,-365],[-22,-357],[60,-371]],pink,2);
      else pixelLimb('rider-arm',[[-73,-365],[-28,-353],[61,-369]],pink,2);
    }else{
      pixelLimb('far-leg',[[-105,-316],[-97,-276],[-34-Math.cos(pedal)*23,-247-Math.sin(pedal)*23]],shade,2);
      pixelLimb('near-leg',[[-105,-316],[-52+Math.cos(pedal)*7,-297],[px,py]],pink,2);
      pixelLimb('rider-arm',[[-73,-365],[-25,-351],[61,-367]],pink,2);
    }
    $('crank').setAttribute('transform',`rotate(${pedal*180/Math.PI} -34 -247)`);
    $('axolotl-tail').setAttribute('transform',`translate(0 ${Math.round(Math.sin(t*4)*2)*3-6*j})`);
    $('rider-pose').setAttribute('transform',`translate(0 ${-Math.round(j*2)*7})`);
  }
  function addObstacle(x){
    const s=state.season,kind=Math.floor(Math.random()*3),width=48+Math.random()*15,height=35+Math.random()*16;
    const g=el('g',{class:'cartoon',transform:`translate(${x} 660)`},$('obstacles'));
    el('ellipse',{cx:width/2,cy:2,rx:width*.68,ry:6,fill:'#536855',opacity:.15,stroke:'none'},g);
    if(s==='spring'&&kind===0){
      path(g,`M0 0L3-${height*.45}Q${width*.5}-${height*1.2} ${width-4}-${height*.55}L${width} 0Z`,'#9bab8b',{'stroke-width':2.5,stroke:'#667d69'});
      path(g,`M10-${height*.33}L${width*.5}-${height*.71}L${width*.7}-${height*.45}`,'none',{stroke:'#c3d0ac','stroke-width':4});
    }else if((s==='spring'&&kind===1)||s==='autumn'&&kind===0){
      rect(g,2,-height,width-4,height,'#b58c5c',{rx:8,'stroke-width':2.5,stroke:'#6b694b'});
      path(g,`M11-${height*.3}H${width-10}M11-${height*.7}H${width-10}M${width*.3}-${height-4}V-4`,'none',{stroke:'#d2ac77','stroke-width':3});
      use(g,'leaf-shape',width*.6,-height-2,.5,{color:'#83a075',stroke:'none'});
    }else if(s==='summer'){
      if(kind===0){
        path(g,`M2 0L7-${height}H${width-10}L${width} 0Z`,'#c7965c',{'stroke-width':2.5,stroke:'#9a784e'});
        path(g,`M15-${height*.3}H${width-11}M15-${height*.65}H${width-17}`,'none',{stroke:'#e6bc7e','stroke-width':3});
      }else if(kind===1){
        path(g,`M9 0Q-5-${height*.5} 15-${height*.8}L11-${height}H${width-13}L${width-17}-${height*.8}Q${width+6}-${height*.4} ${width-7} 0Z`,'#ce9060',{'stroke-width':2.5,stroke:'#996e4d'});
        path(g,`M9-${height*.38}H${width-7}M13-${height*.62}H${width-13}`,'none',{stroke:'#f3ce91','stroke-width':4});
      }else{
        el('ellipse',{cx:width/2,cy:-height/2,rx:width/2,ry:height/2,fill:'#d2af70',stroke:'#ac8955','stroke-width':2.5},g);
        path(g,`M4-${height*.4}Q${width*.5}-${height*1.2} ${width-4}-9M10-5Q${width*.4}-${height*.9} ${width-6}-${height*.65}M7-${height*.7}Q${width*.5}-2 ${width-7}-${height*.2}`,'none',{stroke:'#b39059','stroke-width':2});
      }
    }else if(s==='winter'){
      path(g,`M0 0L7-${height*.62}L${width*.5}-${height}L${width-4}-${height*.65}L${width} 0Z`,'#c6e7e5',{'stroke-width':2.5,stroke:'#6b9fa6'});
      path(g,`M7-${height*.62}L${width*.5}-${height}L${width-4}-${height*.65}L${width*.65}-${height*.48}L${width*.4}-${height*.67}Z`,'#f5fbef',{stroke:'none'});
      path(g,`M${width*.5}-${height*.65}L${width*.43}-7`,'none',{stroke:'#e9fcf2','stroke-width':4});
    }else if(s==='autumn'){
      if(kind===1){path(g,`M0 0Q5-${height*.2} 17-${height*.4}L${width*.5}-${height}Q${width*.8}-${height*.3} ${width} 0Z`,'#cf9554',{'stroke-width':2,stroke:'#a67d4f'});for(let i=0;i<6;i++)use(g,'leaf-shape',10+i*7,-6-(i%3)*8,.5,{color:i%2?'#e9b764':'#c57a43',stroke:'none'});}
      else{path(g,`M7 0L${width*.5-8}-${height}H${width*.5+7}L${width-7} 0Z`,'#d79665',{'stroke-width':2.5,stroke:'#826a50'});path(g,`M15-${height*.38}H${width-15}`,'none',{stroke:'#fff0ce','stroke-width':8});rect(g,0,-4,width,7,'#8c8668',{rx:3,stroke:'none'});}
    }else{
      path(g,`M0-3Q-5-${height} ${width*.3}-${height}H${width*.8}Q${width+7}-${height*.65} ${width-3}-2Z`,'#bc9668',{'stroke-width':2.5,stroke:'#816e50'});
      el('ellipse',{cx:width*.77,cy:-height*.5,rx:width*.2,ry:height*.46,fill:'#e4c894',stroke:'#997b51','stroke-width':2},g);el('ellipse',{cx:width*.77,cy:-height*.5,rx:width*.1,ry:height*.25,fill:'none',stroke:'#b89767','stroke-width':2},g);
    }
    state.obstacles.push({node:g,x,width,height,passed:false,collided:false,checked:false});
  }
  function puff(){for(let i=0;i<8;i++){const node=circle($('dust'),0,0,3+Math.random()*6,palettes[state.season].edge,{opacity:.7});state.particles.push({node,x:ACTOR-155+Math.random()*250,y:657,life:0,vx:-28-Math.random()*70,vy:-20-Math.random()*45});}}
  function startJump(){state.jumpTime=0;state.pose=state.jumps%3;$('jump-word').textContent=['起飞咯！','芜湖～','稳稳的！'][state.pose];puff();}
  function render(dt){
    state.time+=dt;state.travel+=dt*SPEED;state.distance+=dt*SPEED*.028;
    if(state.jumpTime>=0){state.jumpTime+=dt;if(state.jumpTime>=FLIGHT){state.jumpTime=-1;state.land=.38;state.jumps++;puff();}}
    state.land=Math.max(0,state.land-dt);
    const bob=state.jumpTime<0?Math.sin(state.time*8)*1.4:0;
    const p=state.jumpTime>=0?state.jumpTime/FLIGHT:0;
    const arc=state.jumpTime>=0?4*p*(1-p):0, lift=arc*HEIGHT;
    const pitch=state.jumpTime>=0?-Math.sin(p*Math.PI*2)*2.8:0;
    const squash=state.land>0?Math.sin(state.land/.38*Math.PI)*.025:0;
    $('traveller').setAttribute('transform',`translate(${ACTOR} ${BASE-lift+bob})`);
    $('pelican-pose').setAttribute('transform',`rotate(${pitch} 0 -80) scale(1 ${1-squash})`);
    $('bicycle-pose').setAttribute('transform',`translate(0 ${-arc*5}) rotate(${-arc*(state.pose===2?-2.3:2)} -35 -156)`);
    $('wing').setAttribute('transform',`rotate(${-arc*(state.pose===1?25:16)} -122 -104)`);
    $('beak-pouch').setAttribute('transform',`rotate(${arc*5} 234 -164)`);
    $('vehicle-shadow').setAttribute('rx',234-arc*55);$('vehicle-shadow').setAttribute('opacity',.17-arc*.085);
    $('pelican-blink').setAttribute('opacity',state.time%5.4>5.23?1:0);
    spin+=dt*SPEED/32*180/Math.PI;
    document.querySelectorAll('.machine-spin').forEach(n=>n.setAttribute('transform',`rotate(${spin%360})`));
    document.querySelectorAll('.bike-spin').forEach(n=>n.setAttribute('transform',`rotate(${spin*.66%360})`));
    rider(state.time,arc);
    for(const item of scenery)item.node.setAttribute('transform',`translate(${-((state.travel*item.speed)%W)} 0)`);
    $('clouds').setAttribute('transform',`translate(${-((state.time*7)%285)} 0)`);
    for(const item of weather){const x=((item.x-state.time*item.speed)%1540+1540)%1540-50;const y=(item.y+state.time*(state.season==='summer'?3:12))%690;item.node.setAttribute('transform',`translate(${x} ${y}) rotate(${Math.sin(state.time+item.phase)*45})`);}
    state.nextSpawn-=SPEED*dt;
    if(state.nextSpawn<=0){addObstacle(1510);state.nextSpawn=1020+Math.random()*420;}
    for(let i=state.obstacles.length-1;i>=0;i--){
      const o=state.obstacles[i];o.x-=SPEED*dt;o.node.setAttribute('transform',`translate(${o.x} 660)`);
      if(!o.passed && o.x<=ACTOR+280 && o.x+o.width>ACTOR-220 && state.jumpTime<0)startJump();
      // Conservative envelope, expanded beyond the wheels, verifies jump clearance.
      if(o.x<ACTOR+182&&o.x+o.width>ACTOR-230){
        const clearance=lift-o.height-9;state.minClearance=Math.min(state.minClearance,clearance);
        if(clearance<0&&!o.collided){o.collided=true;state.collisions++;}
      }
      if(!o.passed&&o.x+o.width<ACTOR-235){o.passed=true;state.cleared++;}
      if(o.x<-110){o.node.remove();state.obstacles.splice(i,1);}
    }
    for(let i=state.particles.length-1;i>=0;i--){const d=state.particles[i];d.life+=dt;d.x+=d.vx*dt;d.y+=d.vy*dt;d.node.setAttribute('cx',d.x);d.node.setAttribute('cy',d.y);d.node.setAttribute('opacity',Math.max(0,.55-d.life));if(d.life>.6){d.node.remove();state.particles.splice(i,1);}}
    const show=arc>.3;
    $('jump-message').setAttribute('opacity',show?Math.min(1,(arc-.3)*4):0);$('jump-message').setAttribute('transform',`translate(903 ${395-lift*.65}) rotate(${-arc*3})`);
    $('jump-sparkles').setAttribute('opacity',arc*.8);$('jump-sparkles').setAttribute('transform',`translate(${ACTOR-253} ${538-lift*.5})`);
    hudTime+=dt;if(hudTime>.12||dt===0){hudTime=0;$('distance').textContent=Math.floor(state.distance).toString().padStart(3,'0');$('jump-count').textContent=state.jumps.toString().padStart(2,'0');}
    state.frames++;
  }
  function frame(now){
    const elapsed=last?Math.min((now-last)/1000,.06):0;last=now;
    if(!state.paused&&!document.hidden){
      // Small integration steps keep collisions and takeoff timing stable on slow frames.
      let remaining=elapsed*state.speed;while(remaining>0){const dt=Math.min(remaining,1/120);render(dt);remaining-=dt;}
    }
    requestAnimationFrame(frame);
  }
  function syncPause(){
    $('pause').setAttribute('aria-pressed',String(state.paused));$('pause-label').textContent=state.paused?'继续旅程':'暂停旅程';
    $('live-state').textContent=state.paused?'风景等你，旅程暂停':'自动巡游中';$('season-panel').dataset.paused=String(state.paused);
    $('pause-icon').replaceChildren();if(state.paused)path($('pause-icon'),'M4 2L13 8L4 14Z','currentColor');else{rect($('pause-icon'),4,3,3,10,'currentColor',{rx:1});rect($('pause-icon'),9,3,3,10,'currentColor',{rx:1});}
  }
  function setSeason(season,announce=true){
    if(!palettes[season])return;
    state.season=season;state.obstacles.forEach(o=>o.node.remove());state.obstacles=[];state.particles.forEach(o=>o.node.remove());state.particles=[];
    state.jumpTime=-1;state.land=0;state.nextSpawn=950;state.minClearance=Infinity;
    document.querySelectorAll('[data-season]').forEach(button=>{const active=button.dataset.season===season;button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;});
    makeScenery();addObstacle(1380);render(0);
    if(announce)$('announcement').textContent='已切换到'+palettes[season].name+'，'+palettes[season].title+'。';
  }
  document.querySelectorAll('[data-season]').forEach(button=>{
    button.addEventListener('click',()=>setSeason(button.dataset.season));
    button.addEventListener('keydown',event=>{
      const tabs=[...document.querySelectorAll('[data-season]')];let index=tabs.indexOf(button);
      if(event.key==='ArrowRight')index=(index+1)%4;else if(event.key==='ArrowLeft')index=(index+3)%4;else if(event.key==='Home')index=0;else if(event.key==='End')index=3;else return;
      event.preventDefault();tabs[index].focus();setSeason(tabs[index].dataset.season);
    });
  });
  $('pause').addEventListener('click',()=>{state.paused=!state.paused;syncPause();});
  $('speed').addEventListener('click',()=>{const speeds=[1,1.35,.75];state.speed=speeds[(speeds.indexOf(state.speed)+1)%speeds.length];$('speed').textContent=({1:'轻快 ×1',1.35:'追风 ×1.35',.75:'悠游 ×0.75'})[state.speed];$('speed').setAttribute('aria-label','切换骑行速度，当前'+state.speed+'倍');});
  $('restart').addEventListener('click',()=>{state.time=0;state.distance=0;state.jumps=0;state.cleared=0;state.collisions=0;state.travel=0;spin=0;setSeason(state.season,false);$('announcement').textContent='已重新出发。';});
  document.addEventListener('keydown',event=>{if(event.code==='Space'&&!event.repeat&&!event.target.closest('button,input,textarea,select,[contenteditable]')){event.preventDefault();state.paused=!state.paused;syncPause();}});
  document.addEventListener('visibilitychange',()=>{last=0;});
  const resizeScene=()=>{
    const box=$('world').getBoundingClientRect(),small=innerWidth<=600,height=small?960:816;
    const width=Math.min(1440,box.width/box.height*height),left=Math.max(0,Math.min(250,(1440-width)/2-65));
    $('world').setAttribute('viewBox',`${left} ${small?-180:-36} ${width} ${height}`);
  };
  new ResizeObserver(resizeScene).observe($('world'));
  setSeason('spring',false);syncPause();requestAnimationFrame(frame);
  // Read-only state for checking the finished animation without changing its behavior.
  Object.defineProperty(window,'rideStatus',{get:()=>Object.freeze({season:state.season,paused:state.paused,speed:state.speed,distance:Math.floor(state.distance),jumps:state.jumps,cleared:state.cleared,collisions:state.collisions,minClearance:Number.isFinite(state.minClearance)?Math.round(state.minClearance*10)/10:null,airborne:state.jumpTime>=0,obstacles:state.obstacles.length,frames:state.frames})});
})();
