const fs = require('node:fs');
const html = fs.readFileSync('outputs/四季奇旅.html','utf8');
const assertions = {
  inlineJavaScript: (html.match(/<script>/g)||[]).length === 1 && !/<script[^>]+src\s*=/i.test(html),
  noExternalAssets: !/<(?:img|link|iframe|audio|video)\b|@import|@font-face|fetch\s*\(|XMLHttpRequest|src\s*=/i.test(html),
  localSvgLinksOnly: [...html.matchAll(/href="([^"]+)"/g)].every(x=>x[1].startsWith('#')),
  allFourSeasons: ['spring','summer','autumn','winter'].every(s=>html.includes('data-season="'+s+'"')),
  fourMachineWheels: (html.match(/class="machine-spin"/g)||[]).length === 4,
  axolotlCrispEdges: html.includes('shape-rendering:crispEdges'),
};
console.log(JSON.stringify(assertions,null,2));
if(Object.values(assertions).some(x=>!x))process.exit(1);
