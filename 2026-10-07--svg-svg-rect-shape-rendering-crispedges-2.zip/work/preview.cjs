const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../outputs');
http.createServer((req,res) => {
  if (req.url === '/favicon.ico') { res.writeHead(204); res.end(); return; }
  const file = path.join(root, '四季奇旅.html');
  res.writeHead(200, {'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
  res.end(fs.readFileSync(file));
}).listen(18743, '127.0.0.1', () => console.log('Preview ready: http://127.0.0.1:18743'));
