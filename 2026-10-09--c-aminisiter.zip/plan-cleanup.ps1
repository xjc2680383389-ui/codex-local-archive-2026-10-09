$ErrorActionPreference = 'Stop'
$base = 'C:\Users\Administrator'
$cutoff = (Get-Date).AddDays(-7)
$definitions = @(
    @{Relative='AppData\LocalLow\TeamSoda\Duckov\Player.log';OldOnly=$false},
    @{Relative='AppData\LocalLow\TeamSoda\Duckov\Player-prev.log';OldOnly=$false},
    @{Relative='AppData\Local\Microsoft\Edge\User Data\Default\Cache';OldOnly=$false},
    @{Relative='AppData\Local\Microsoft\Edge\User Data\Default\Code Cache';OldOnly=$false},
    @{Relative='AppData\Roaming\bilibili\Cache';OldOnly=$false},
    @{Relative='AppData\Roaming\bilibili\Code Cache';OldOnly=$false},
    @{Relative='AppData\Local\Steam\htmlcache\Default\Code Cache';OldOnly=$false},
    @{Relative='AppData\Local\npm-cache\_cacache';OldOnly=$false},
    @{Relative='AppData\Local\Temp';OldOnly=$true}
)
function Assert-PlainPath([string]$Path) {
    $absolute = [IO.Path]::GetFullPath($Path)
    if (-not $absolute.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)) { throw "Outside scope: $absolute" }
    $check = $absolute
    while ($check.Length -ge $base.Length) {
        if ([IO.File]::Exists($check) -or [IO.Directory]::Exists($check)) {
            if (([IO.File]::GetAttributes($check) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link excluded: $check" }
        }
        $check = [IO.Path]::GetDirectoryName($check)
        if (-not $check) { break }
    }
    return $absolute
}
$files = [Collections.Generic.List[object]]::new()
$skipped = [Collections.Generic.List[object]]::new()
foreach ($definition in $definitions) {
    $target = Assert-PlainPath (Join-Path $base $definition.Relative)
    $stack = [Collections.Generic.Stack[string]]::new()
    if ([IO.Directory]::Exists($target)) { $stack.Push($target) }
    elseif ([IO.File]::Exists($target)) { $stack.Push([IO.Path]::GetDirectoryName($target)) }
    else { continue }
    while ($stack.Count -gt 0) {
        $dir = $stack.Pop()
        foreach ($entry in [IO.DirectoryInfo]::new($dir).EnumerateFileSystemInfos()) {
            if ([IO.File]::Exists($target) -and $entry.FullName -ne $target) { continue }
            if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { $skipped.Add(@{Path=$entry.FullName;Reason='Link'});continue }
            if (($entry.Attributes -band [IO.FileAttributes]::Directory) -ne 0) { $stack.Push($entry.FullName);continue }
            if ($definition.OldOnly -and $entry.LastWriteTime -ge $cutoff) { continue }
            $files.Add([pscustomobject]@{Path=$entry.FullName;Target=$target;Bytes=$entry.Length;LastWriteUtc=$entry.LastWriteTimeUtc.ToString('o');OldOnly=$definition.OldOnly})
        }
    }
}
$savePath = Join-Path $base 'AppData\LocalLow\TeamSoda\Duckov\Saves'
$saveHashes = @(Get-ChildItem -LiteralPath $savePath -File -Recurse | Get-FileHash -Algorithm SHA256 | Select-Object Path,Hash)
$preserve = @('Videos\bilibili','.cache\codex-runtimes','.codex','.zcode','OneDrive','Saved Games','xwechat_files','tools','AppData\Roaming\Vortex')
$plan = [pscustomobject]@{Created=(Get-Date).ToString('o');Base=$base;Cutoff=$cutoff.ToUniversalTime().ToString('o');Files=$files;Skipped=$skipped;SaveHashes=$saveHashes;Preserve=@($preserve | ForEach-Object {[pscustomobject]@{Path=(Join-Path $base $_);Exists=(Test-Path -LiteralPath (Join-Path $base $_))}})}
$plan | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'cleanup-plan.json') -Encoding utf8
$files | Group-Object Target | ForEach-Object {[pscustomobject]@{Target=$_.Name;Files=$_.Count;MiB=[math]::Round(($_.Group | Measure-Object Bytes -Sum).Sum/1MB,2)}} | ConvertTo-Json
