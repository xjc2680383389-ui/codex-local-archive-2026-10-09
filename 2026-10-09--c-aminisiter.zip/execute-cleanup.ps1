$ErrorActionPreference = 'Stop'
$plan = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'cleanup-plan.json') -Raw | ConvertFrom-Json
$base = 'C:\Users\Administrator'
$allowed = @(
 'AppData\LocalLow\TeamSoda\Duckov\Player.log',
 'AppData\LocalLow\TeamSoda\Duckov\Player-prev.log',
 'AppData\Local\Microsoft\Edge\User Data\Default\Cache',
 'AppData\Local\Microsoft\Edge\User Data\Default\Code Cache',
 'AppData\Roaming\bilibili\Cache',
 'AppData\Roaming\bilibili\Code Cache',
 'AppData\Local\Steam\htmlcache\Default\Code Cache',
 'AppData\Local\npm-cache\_cacache',
 'AppData\Local\Temp'
) | ForEach-Object { Join-Path $base $_ }
$active = @(Get-Process | Where-Object {$_.ProcessName -match '^(msedge|bilibili|steam|steamwebhelper|Duckov|EscapeFromDuckov|npm)$'})
if ($active.Count) { throw ('Relevant application started; cleanup stopped: '+($active.ProcessName -join ', ')) }
$freeBefore = (Get-Volume -DriveLetter C).SizeRemaining
$deleted = [Collections.Generic.List[object]]::new()
$skipped = [Collections.Generic.List[object]]::new()
foreach ($file in $plan.Files) {
 try {
    $path = [IO.Path]::GetFullPath($file.Path)
    $target = [IO.Path]::GetFullPath($file.Target)
    if ($allowed -notcontains $target) { throw 'Target not on exact allowlist' }
    if (-not ($path -eq $target -or $path.StartsWith($target+'\',[StringComparison]::OrdinalIgnoreCase))) { throw 'File outside its approved target' }
    if (-not $path.StartsWith($base+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'File outside user scope' }
    $check = $path
    while ($check.Length -ge $base.Length) {
      if (([IO.File]::Exists($check) -or [IO.Directory]::Exists($check)) -and (([IO.File]::GetAttributes($check) -band [IO.FileAttributes]::ReparsePoint) -ne 0)) { throw 'Reparse point excluded' }
      $check = [IO.Path]::GetDirectoryName($check)
      if (-not $check) { break }
    }
    if (-not [IO.File]::Exists($path)) { $skipped.Add(@{Path=$path;Reason='Already absent'});continue }
    $info = [IO.FileInfo]::new($path)
    if ($info.Length -ne $file.Bytes -or $info.LastWriteTimeUtc.Ticks -ne ([datetime]$file.LastWriteUtc).ToUniversalTime().Ticks) { throw 'Changed since inspection' }
    if ($file.OldOnly -and $info.LastWriteTimeUtc -ge ([datetime]$plan.Cutoff).ToUniversalTime()) { throw 'Recent temporary file' }
    $handle = [IO.File]::Open($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::None)
    $handle.Dispose()
    Remove-Item -LiteralPath $path -Force -ErrorAction Stop
    if (Test-Path -LiteralPath $path) { throw 'File remains after deletion' }
    $deleted.Add(@{Path=$path;Target=$target;Bytes=$file.Bytes})
 } catch { $skipped.Add(@{Path=$file.Path;Reason=$_.Exception.Message}) }
}
$freeAfter = (Get-Volume -DriveLetter C).SizeRemaining
$result = [pscustomobject]@{Finished=(Get-Date).ToString('o');FreeBeforeBytes=$freeBefore;FreeAfterBytes=$freeAfter;NetFreedGiB=[math]::Round(($freeAfter-$freeBefore)/1GB,3);DeletedFiles=$deleted.Count;DeletedLogicalGiB=[math]::Round(($deleted | Measure-Object Bytes -Sum).Sum/1GB,3);Deleted=$deleted;Skipped=$skipped}
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'cleanup-result.json') -Encoding utf8
$result | Select-Object Finished,NetFreedGiB,DeletedFiles,DeletedLogicalGiB,@{n='SkippedFiles';e={$_.Skipped.Count}},@{n='SkipSamples';e={@($_.Skipped | Select-Object -First 5)}} | ConvertTo-Json -Depth 4
