# Administrator 用户目录清理候选

检查日期：2026-10-09。以下大小为清理前的检查结果。

## 清理结果

用户授权后，已清理优先候选中的 9,921 个文件，删除文件逻辑大小合计 2.449 GiB；清理前后 C 盘可用空间实测增加 2.466 GiB，复核时剩余 434.554 GiB。
清单中的已删除文件均确认不再存在。两项临时文件因访问被拒绝而保留，合计约 4.25 MiB，位于 `AppData\Local\Temp\is-M8IKYZS321-uninstall.tmp` 下，分别为 `_unins-done.tmp`、`_unins.tmp`。近期临时文件和空目录保留。
Duckov 的 20 个存档文件 SHA-256 与清理前一致；视频、OneDrive、微信、游戏存档、MOD、工具与 Codex/ZCode 目录均仍存在。额外条件项目未清理。
详细执行记录见 `cleanup-result.json`，核验记录见 `cleanup-verification.json`。
所有相对路径均以 `C:\Users\Administrator\` 为根目录。大小是文件逻辑大小，实际释放空间可能受硬链接、压缩、文件占用及缓存重建影响。

## 优先候选（约 2.45 GiB）

清理缓存前退出对应应用；仅删除下列明确文件或目录中的缓存内容，不扩大到其父目录。

| 对象 | 相对路径 | 文件大小 | 边界与影响 |
|---|---|---:|---|
| Duckov 旧游戏日志 | `AppData\LocalLow\TeamSoda\Duckov\Player.log` 和 `Player-prev.log` | 合计 842.87 MiB | 修改日期为 2025-11-15/16；不需要这些日志排障时可删。保留同目录 `Saves`、`ModSetting`、`FirstPersonCamera` 和 `steam_autocloud.vdf` |
| 七天前的临时文件 | `AppData\Local\Temp` | 163.9 MiB | 全目录 512.2 MiB；只考虑最后修改超过七天且当前未占用的普通文件。日期筛选本身不能证明未占用，保留近期文件，跳过链接和删除失败项 |
| npm 下载缓存 | `AppData\Local\npm-cache\_cacache` | 165.0 MiB | 可重建；后续安装依赖需要重新下载。保留 `AppData\Roaming\npm` 中的全局工具 |
| Edge 普通网页缓存 | `AppData\Local\Microsoft\Edge\User Data\Default\Cache` 和 `Code Cache` | 合计 623.0 MiB | 通过浏览器“缓存的图像和文件”选项清理；不选择密码、Cookie、历史记录，也不删除整个 User Data |
| 哔哩哔哩界面缓存 | `AppData\Roaming\bilibili\Cache` 和 `Code Cache` | 合计 416.1 MiB | 退出客户端后清理；保留 `Videos\bilibili` 下载的视频 |
| Steam 网页代码缓存 | `AppData\Local\Steam\htmlcache\Default\Code Cache` | 301.0 MiB | 退出 Steam 后可清理；保留登录数据、游戏、存档及其他目录 |

本次进程检查未检出 Steam、哔哩哔哩、Duckov、Edge 主程序；检测到 Codex 和 WebView2 正在运行。实际清理前需重新检查，因为进程状态会变化。

## 需要额外条件的项目

- 剪映 `AppData\Local\JianyingPro\User Data\Cache`：305.6 MiB。建议使用剪映内置缓存清理，保留草稿、资源和 `ComponentStore`。
- Edge `Service Worker\CacheStorage`：489.0 MiB。可能包含网站离线资源，清理后相应网站需重新下载；不纳入默认清理。
- 小米 MiMo `AppData\Local\xiaomi-mimo-desktop-updater\installer.exe`：239.82 MiB。需确认安装或更新已完成，没有待执行更新。
- `tools\_installers\tesseract-ocr-w64-setup-5.5.3.exe`：25.34 MiB。确认不需要重新安装后可删除。
- `AppData\Local\@zcodedesktop-updater\pending`：170.4 MiB。属于待更新目录，暂不建议清理。
- Codex 网页缓存和日志：当前正在使用，暂不纳入清理。相同大小的缓存还出现在应用包 LocalCache 下，未做硬链接去重，不能将两套大小直接相加为可释放空间。
- `AppData\Local\NRC\Saved\ProgramBinaryCache`：547.0 MiB。像是游戏着色器预缓存，未核对具体游戏的重建行为，暂不纳入清理。

## 保留项目

- `Videos\bilibili`：29.79 GiB，下载的视频。仅在用户决定不再保留后删除。
- `OneDrive`：约 5.44 GiB。需要节省本地空间时可考虑“释放空间”，避免普通删除同步到云端；此次未核对同步状态。
- `AppData\Roaming\Vortex`：约 2.07 GiB，包含游戏 MOD 内容。
- `AppData\Roaming\baidu\BaiduNetdisk`：约 1.69 GiB，检查发现可执行程序、DLL 和 module，不能整体按缓存删除。
- `.cache\codex-runtimes`：约 1.30 GiB，包含 Codex 运行组件。
- `.zcode`：工作区、程序和数据库；`.codex`：会话、记忆、配置、插件、程序和数据库。均不可整体删除。
- `tools`：MiKTeX、OCR、FFmpeg 等工具；`Saved Games`、微信聊天文件、Documents 和用户注册表文件 `NTUSER.DAT` 及相关文件。

原始目录与大文件统计见 `profile-usage.json`；扫描跳过 72 个重解析项，没有枚举错误。扫描未对内容执行安全检测，也未确认应用可重建所有名字中带 cache 的目录。

参考：[微软磁盘空间清理说明](https://support.microsoft.com/en-us/windows/experience/storage-filemanagement/free-up-drive-space-in-windows)、[npm 缓存文档](https://docs.npmjs.com/cli/v11/commands/npm-cache/)、[Unity 日志位置说明](https://docs.unity3d.com/6000.0/Documentation/Manual/log-files.html)。
