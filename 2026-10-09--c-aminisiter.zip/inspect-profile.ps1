$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.IO;
using System.Collections.Generic;
public class UsageEntry {
 public string Path; public long Bytes; public long Files; public long OldBytes;
 public DateTime LastWrite;
}
public class UsageReport {
 public List<UsageEntry> Directories=new List<UsageEntry>();
 public List<UsageEntry> LargeFiles=new List<UsageEntry>();
 public int SkippedLinks; public List<string> Errors=new List<string>();
}
public static class ProfileInspector {
 public static UsageReport Run(string root) {
  var report=new UsageReport(); var stack=new Stack<string>(); stack.Push(root);
  var map=new Dictionary<string,UsageEntry>(StringComparer.OrdinalIgnoreCase);
  var cutoff=DateTime.Now.AddDays(-7);
  while(stack.Count>0) {
   string path=stack.Pop();
   if(!map.ContainsKey(path))map[path]=new UsageEntry{Path=path};
   try {
    foreach(var entry in new DirectoryInfo(path).EnumerateFileSystemInfos()) {
     try {
      if((entry.Attributes & FileAttributes.ReparsePoint)!=0){report.SkippedLinks++;continue;}
      if((entry.Attributes & FileAttributes.Directory)!=0){stack.Push(entry.FullName);continue;}
      var file=(FileInfo)entry; long bytes=file.Length; var modified=file.LastWriteTime;
      if(bytes>=100L*1024*1024)report.LargeFiles.Add(new UsageEntry{Path=file.FullName,Bytes=bytes,Files=1,LastWrite=modified});
      string parent=path;
      while(parent!=null && (parent.Equals(root,StringComparison.OrdinalIgnoreCase)||parent.StartsWith(root+"\\",StringComparison.OrdinalIgnoreCase))) {
       UsageEntry row;
       if(!map.TryGetValue(parent,out row)){row=new UsageEntry{Path=parent};map[parent]=row;}
       row.Bytes+=bytes;row.Files++;
       if(modified<cutoff)row.OldBytes+=bytes;
       if(modified>row.LastWrite)row.LastWrite=modified;
       parent=Path.GetDirectoryName(parent);
      }
     }catch(Exception ex){report.Errors.Add(entry.FullName+" : "+ex.GetType().Name);}
    }
   }catch(Exception ex){report.Errors.Add(path+" : "+ex.GetType().Name);}
  }
  report.Directories.AddRange(map.Values);return report;
 }
}
'@
$report=[ProfileInspector]::Run('C:\Users\Administrator')
$outputPath=Join-Path $PSScriptRoot 'profile-usage.json'
$report | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $outputPath -Encoding utf8
[pscustomobject]@{Report=$outputPath;Directories=$report.Directories.Count;LargeFiles=$report.LargeFiles.Count;SkippedLinks=$report.SkippedLinks;Errors=$report.Errors.Count} | ConvertTo-Json
