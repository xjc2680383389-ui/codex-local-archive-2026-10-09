import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const file = path.resolve('outputs/四季搭子.html');
const html = fs.readFileSync(file, 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
new vm.Script(script, {filename:'四季搭子.html'});
const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
const duplicates = ids.filter((v,i)=>ids.indexOf(v)!==i);
const refs = [...html.matchAll(/(?:href="#|url\(#)([^"')]+)["')]/g)].map(m=>m[1]);
const missing = refs.filter(v=>!ids.includes(v));
const external = [...html.matchAll(/(?:src|href)=["'](?!#|data:)([^"']+)/g)].map(m=>m[1]);
console.log(JSON.stringify({scriptSyntax:'PASS',bytes:Buffer.byteLength(html),duplicateIds:duplicates,missingReferences:missing,externalResources:external}));
http.createServer((req,res)=>{
  if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
  if(req.url==='/' || req.url.startsWith('/ride.html')){
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});res.end(fs.readFileSync(file));
  }else{res.writeHead(404);res.end('Not found');}
}).listen(18742,'127.0.0.1',()=>console.log('Preview ready: http://127.0.0.1:18742/ride.html'));
