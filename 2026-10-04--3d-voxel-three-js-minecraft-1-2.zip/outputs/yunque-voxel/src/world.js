import * as THREE from 'three';

// All geometry is authored here from boxes. No models, textures, or source assets.
const P = {
  stone: ['#cbc5ad', '#c2bda8', '#d4ceb9', '#b9b6a4', '#cec9b4'],
  paving: ['#c8cbbb', '#bec4b6', '#d0d2c3', '#c3c8bb'],
  red: ['#a44a32', '#ad5238', '#99432e', '#b45a3b'],
  wood: ['#674734', '#79533b', '#855f42', '#70503b'],
  gold: ['#cd9b45', '#dbaa50', '#bd8b3b', '#dbb45c', '#c79943'],
  jade: ['#3b6b5e', '#447565', '#335e54', '#50806b', '#39685d'],
  leaves: ['#4e704c', '#5a7c51', '#638556', '#456443', '#6d8a58'],
  autumn: ['#c4a343', '#d2b74c', '#cbb24f', '#b59b40'],
};

function hash(x, y = 0, z = 0) {
  const v = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return v - Math.floor(v);
}
function pick(palette, x, y = 0, z = 0) {
  return palette[Math.floor(hash(x, y, z) * palette.length)];
}

class VoxelBatch {
  constructor() {
    this.buckets = new Map();
    this.pose = { x: 0, y: 0, z: 0, angle: 0 };
    this.count = 0;
  }

  at(x, y, z, angle, build) {
    const prev = this.pose;
    const c = Math.cos(prev.angle), s = Math.sin(prev.angle);
    this.pose = { x: prev.x + c * x + s * z, y: prev.y + y,
      z: prev.z - s * x + c * z, angle: prev.angle + angle };
    build();
    this.pose = prev;
  }

  box(x, y, z, w, h, d, color, kind = 'stone') {
    if (w <= 0 || h <= 0 || d <= 0) return;
    const p = this.pose, c = Math.cos(p.angle), s = Math.sin(p.angle);
    if (!this.buckets.has(kind)) this.buckets.set(kind, []);
    this.buckets.get(kind).push({ x: p.x + c * x + s * z, y: p.y + y,
      z: p.z - s * x + c * z, w, h, d, angle: p.angle, color });
    this.count++;
  }

  finish(scene) {
    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const temp = new THREE.Object3D();
    const color = new THREE.Color();
    const meshes = [], glowMaterials = [];
    for (const [kind, blocks] of this.buckets) {
      const material = new THREE.MeshStandardMaterial({
        color: '#ffffff', roughness: kind === 'metal' ? 0.55 : 0.93,
        metalness: kind === 'metal' ? 0.28 : 0,
        ...(kind === 'glow' ? { emissive: '#ffb75b', emissiveIntensity: 0.45 } : {}),
      });
      const mesh = new THREE.InstancedMesh(geometry, material, blocks.length);
      mesh.name = `voxel-${kind}`;
      mesh.castShadow = !['ground', 'water', 'glow'].includes(kind);
      mesh.receiveShadow = kind !== 'glow';
      blocks.forEach((v, i) => {
        temp.position.set(v.x, v.y, v.z);
        temp.rotation.set(0, v.angle, 0);
        temp.scale.set(v.w, v.h, v.d);
        temp.updateMatrix();
        mesh.setMatrixAt(i, temp.matrix);
        mesh.setColorAt(i, color.set(v.color));
      });
      mesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);
      mesh.instanceMatrix.needsUpdate = true;
      mesh.instanceColor.needsUpdate = true;
      mesh.computeBoundingSphere();
      scene.add(mesh);
      meshes.push(mesh);
      if (kind === 'glow') glowMaterials.push(material);
    }
    return { meshes, glowMaterials, voxelCount: this.count, batches: meshes.length };
  }
}

function paving(b, x, z, width, depth, tile = 2.2, accent = false, elevation = 0) {
  b.box(x, 0.045 + elevation, z, width, 0.11, depth, '#949e90', 'ground');
  const nx = Math.ceil(width / tile), nz = Math.ceil(depth / tile);
  const sx = width / nx, sz = depth / nz;
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const px = x - width / 2 + (i + 0.5) * sx;
    const pz = z - depth / 2 + (j + 0.5) * sz;
    const border = accent && (i === 0 || i === nx - 1);
    b.box(px, 0.12 + elevation, pz, sx - 0.035, 0.1, sz - 0.035,
      border ? '#9ba695' : pick(P.paving, px, 0, pz), 'ground');
  }
}

function foundation(b, w, d, height, stairs = true, stairWidth = 8, bothSides = false) {
  b.box(0, height / 2, 0, w, height, d, '#aaa68e');
  b.box(0, 0.16, 0, w + 0.7, 0.3, d + 0.7, '#bdb9a3');
  b.box(0, height - 0.15, 0, w + 0.45, 0.3, d + 0.45, '#ddd4bb');
  const brick = 1.45;
  for (let y = 0.45; y < height - 0.3; y += 0.44) {
    for (let x = -w / 2 + brick / 2; x < w / 2; x += brick) {
      for (const side of [-1, 1]) b.box(x, y, side * d / 2, brick - 0.025, 0.405, 0.13, pick(P.stone, x, y, side));
    }
    for (let z = -d / 2 + brick / 2; z < d / 2; z += brick) {
      for (const side of [-1, 1]) b.box(side * w / 2, y, z, 0.13, 0.405, brick - 0.025, pick(P.stone, side, y, z));
    }
  }
  if (stairs) {
    const n = Math.ceil(height / 0.3), run = 0.62;
    for (const direction of bothSides ? [1, -1] : [1]) {
      for (let i = 0; i < n; i++) {
        const stepH = height * (n - i) / n;
        const z = direction * (d / 2 + 0.3 + i * run);
        b.box(0, stepH / 2, z, stairWidth, stepH, run + 0.015, pick(P.stone, i, 3));
        for (const side of [-1, 1]) b.box(side * (stairWidth / 2 + 0.32), stepH + 0.2,
          z, 0.52, 0.52, run + 0.02, '#dad1b8');
      }
    }
  }
}

function pillar(b, x, z, base, height, size = 0.78) {
  b.box(x, base + 0.17, z, size + 0.35, 0.34, size + 0.35, '#c9c1a5');
  b.box(x, base + 0.47, z, size + 0.15, 0.28, size + 0.15, '#8c4631', 'clay');
  for (let y = 0.6; y < height - 0.28; y += 0.65) {
    b.box(x, base + y + 0.26, z, size, Math.min(0.67, height - y), size,
      pick(P.red, x, y, z), 'clay');
  }
  b.box(x, base + height - 0.06, z, size + 0.12, 0.28, size + 0.12, '#d0a55b', 'wood');
}

function bracket(b, x, z, y, size = 1) {
  // Stepped dougong: a bearing block, crossed arms, and projecting upper arms.
  b.box(x, y, z, 0.85 * size, 0.32, 0.85 * size, '#76523a', 'wood');
  for (let i = 0; i < 3; i++) {
    const length = (1.25 + i * 0.7) * size;
    const h = y + 0.28 + i * 0.29;
    b.box(x, h, z, length, 0.23, 0.42 * size, i === 2 ? '#c89d57' : '#aa7546', 'wood');
    b.box(x, h + 0.08, z, 0.42 * size, 0.23, length, '#a57446', 'wood');
    for (const side of [-1, 1]) {
      b.box(x + side * (length / 2 - 0.2), h + 0.2, z, 0.38 * size, 0.3, 0.5 * size, '#d2a962', 'wood');
      b.box(x, h + 0.2, z + side * (length / 2 - 0.2), 0.5 * size, 0.3, 0.38 * size, '#bd8a4c', 'wood');
    }
  }
}

function windowPanel(b, x, z, bottom, w, h, sideways = false) {
  b.at(x, 0, z, sideways ? Math.PI / 2 : 0, () => {
    b.box(0, bottom + h / 2, 0, w, h, 0.13, '#402e25', 'wood');
    b.box(0, bottom + h * 0.59, 0.085, w - 0.28, h * 0.67, 0.09, '#c8b281', 'wood');
    for (const side of [-1, 1]) b.box(side * (w / 2 - 0.1), bottom + h / 2, 0.16, 0.18, h, 0.18, '#7d5132', 'wood');
    for (let y = 0; y <= h + 0.01; y += h / 6) {
      b.box(0, bottom + y, 0.18, w, 0.105, 0.16, '#835837', 'wood');
    }
    const n = Math.max(3, Math.round(w / 0.45));
    for (let i = 1; i < n; i++) {
      b.box(-w / 2 + i * w / n, bottom + h * 0.64, 0.18, 0.085, h * 0.69, 0.16, '#835837', 'wood');
    }
    b.box(0, bottom + h * 0.16, 0.18, w - 0.28, h * 0.24, 0.12, '#7a412b', 'clay');
    b.box(0, bottom + h * 0.24, 0.27, 0.07, h * 0.42, 0.1, '#ba9451', 'metal');
    b.box(0.17, bottom + h * 0.29, 0.3, 0.11, 0.2, 0.09, '#d6b15e', 'metal');
  });
}

function lantern(b, x, y, z, size = 1) {
  b.box(x, y + 0.86 * size, z, 0.065, 0.62 * size, 0.065, '#483c2b', 'metal');
  b.box(x, y, z, 0.76 * size, 1.05 * size, 0.76 * size, '#ed974f', 'glow');
  for (const dy of [-0.58, 0.58]) b.box(x, y + dy * size, z, 0.92 * size, 0.16 * size, 0.92 * size, '#8a3b28', 'clay');
  for (const dx of [-0.28, 0.28]) for (const dz of [-0.28, 0.28]) {
    b.box(x + dx * size, y, z + dz * size, 0.065, 1.1 * size, 0.065, '#b94325', 'clay');
  }
  b.box(x, y - 0.94 * size, z, 0.12 * size, 0.56 * size, 0.12 * size, '#bf5529', 'clay');
}

function roof(b, { w, d, y, rise, style = 'hip', gold = false, unit = 0.72, finial = true }) {
  const nx = Math.floor(w / unit), nz = Math.floor(d / unit);
  const sx = w / nx, sz = d / nz;
  const hx = w / 2 - sx / 2, hz = d / 2 - sz / 2;
  const ridgeHalf = style === 'pyramid' ? 0 : Math.max(0, hx - hz);
  const gableHalf = Math.max(sx, hx - hz * 0.49);
  const palette = gold ? P.gold : P.jade;
  const tileH = 0.57;
  const heightAt = (x, z) => {
    const ax = Math.abs(x), az = Math.abs(z);
    const qz = az / hz;
    let q;
    if (style === 'xie') {
      if (qz < 0.46 && ax > gableHalf + sx * 0.4) return null;
      const qx = ax > gableHalf ? 0.46 + (ax - gableHalf) / (hx - gableHalf) * 0.54 : 0;
      q = Math.max(qz, qx);
    } else {
      q = Math.max(qz, Math.max(0, (ax - ridgeHalf) / Math.max(sx, hx - ridgeHalf)));
    }
    const lift = Math.pow(Math.max(0, (q - 0.73) / 0.27), 2) * 1.1;
    const corner = Math.pow(ax / hx, 8) * Math.pow(az / hz, 8) * 1.5;
    return y + Math.round((rise * (1 - q) + lift + corner) / 0.29) * 0.29;
  };
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const x = -hx + i * sx, z = -hz + j * sz;
    const h = heightAt(x, z);
    if (h === null) continue;
    b.box(x, h, z, sx - 0.017, tileH, sz - 0.017, pick(palette, i, y, j), 'roof');
    const edge = i === 0 || j === 0 || i === nx - 1 || j === nz - 1;
    if (edge) {
      b.box(x, h - 0.51, z, sx, 0.47, sz, '#633e2c', 'wood');
      b.box(x, h - 0.3, z, sx + 0.015, 0.15, sz + 0.015, gold ? '#b8883d' : '#86a382', 'roof');
    }
  }
  // Raised ridge, end ornaments, and stepped corner ridges are also boxes.
  const ridge = style === 'xie' ? gableHalf : ridgeHalf;
  if (style !== 'pyramid') {
    for (let x = -ridge; x <= ridge + 0.01; x += sx) {
      b.box(x, y + rise + 0.42, 0, sx - 0.015, 0.42, 0.7, gold ? '#e3ba63' : '#82a18a', 'roof');
      b.box(x, y + rise + 0.72, 0, sx - 0.02, 0.18, 0.42, '#d8b068', 'metal');
    }
    for (const side of [-1, 1]) {
      for (let k = 0; k < 4; k++) {
        b.box(side * (ridge + k * 0.3), y + rise + 0.62 + k * 0.33, 0, 0.55, 0.47, 0.6,
          gold ? '#b88031' : '#4e7664', 'roof');
      }
      b.box(side * (ridge + 0.58), y + rise + 1.53, 0, 0.39, 0.55, 0.38, '#dcaf55', 'metal');
    }
  } else if (finial) {
    for (let k = 0; k < 4; k++) b.box(0, y + rise + 0.3 + k * 0.32, 0,
      1.0 - k * 0.18, 0.32, 1.0 - k * 0.18, '#d5aa59', 'metal');
    b.box(0, y + rise + 1.9, 0, 0.22, 1.15, 0.22, '#d8b35e', 'metal');
  }
  for (const sideX of [-1, 1]) for (const sideZ of [-1, 1]) {
    for (let k = 0; k < 9; k++) {
      const t = k / 8;
      const x = sideX * (ridge + (hx - ridge) * t), z = sideZ * hz * t;
      const h = heightAt(x, z);
      if (h === null) continue;
      b.box(x, h + 0.4, z, sx * 0.77, 0.3, sz * 0.77, gold ? '#e0b05b' : '#80a18a', 'roof');
    }
    b.box(sideX * (hx + 0.25), y + 2.98, sideZ * (hz + 0.25), 0.42, 0.7, 0.42,
      gold ? '#e1b569' : '#7c9a78', 'roof');
  }
  if (style === 'xie') {
    const bottom = y + rise * 0.54;
    for (const side of [-1, 1]) {
      for (let z = -hz * 0.44; z <= hz * 0.44; z += sz) {
        const top = y + rise * (1 - Math.abs(z) / hz) - 0.25;
        for (let yy = bottom; yy <= top; yy += 0.44) {
          b.box(side * gableHalf, yy, z, 0.27, 0.45, sz - 0.02, pick(P.wood, side, yy, z), 'wood');
        }
      }
    }
  }
}

function wall(b, w, h, base, z) {
  const nx = Math.ceil(w / 1.0), ny = Math.ceil(h / 0.64);
  const sx = w / nx, sy = h / ny;
  for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) {
    b.box(-w / 2 + sx * (i + 0.5), base + sy * (j + 0.5), z,
      sx - 0.01, sy - 0.01, 0.36, pick(P.red, i, j, z), 'clay');
  }
}

function hall(b, { w, d, base, h, bays, main = false }) {
  foundation(b, w + 2.7, d + 2.5, base, true, main ? 12 : 6);
  const wallZ = d / 2 - 1.85;
  wall(b, w - 0.5, h - 0.9, base, -d / 2 + 0.5);
  for (const side of [-1, 1]) {
    b.at(side * (w / 2 - 0.6), 0, 0, Math.PI / 2, () => {
      wall(b, d - 0.9, h - 0.9, base, 0);
      for (const z of [-d * 0.26, d * 0.26]) windowPanel(b, z, side * 0.2, base + 1.5, d * 0.28, h * 0.5);
    });
  }
  const span = (w - 1.7) / bays;
  for (let i = 0; i <= bays; i++) {
    const x = -(w - 1.7) / 2 + i * span;
    for (const z of [-d / 2 + 0.6, d / 2 - 0.5]) {
      pillar(b, x, z, base, h, main ? 0.88 : 0.72);
      bracket(b, x, z, base + h, main ? 1.12 : 0.88);
    }
    if (i < bays) {
      const center = x + span / 2;
      const panelW = span - 0.66;
      windowPanel(b, center, wallZ, base + 0.32, panelW, h - 1.3);
      b.box(center, base + h - 0.32, wallZ, panelW, 0.64, 0.55, '#93452d', 'clay');
      b.box(center, base + h - 0.5, d / 2 - 0.26, panelW, 0.19, 0.32, '#ccae72', 'wood');
      if (i % 2 === 0) lantern(b, center, base + h - 1.65, d / 2 + 0.48, main ? 0.95 : 0.72);
    }
  }
  for (const z of [-d / 2 + 0.5, d / 2 - 0.35]) {
    b.box(0, base + h + 0.63, z, w + 0.8, 0.6, 0.64, '#6d4c32', 'wood');
    b.box(0, base + h + 0.93, z, w + 0.85, 0.16, 0.7, '#d0aa5f', 'wood');
  }
  b.box(0, base + h - 0.85, d / 2 + 0.11, main ? 5.3 : 3.4, 1.25, 0.34, '#264d45', 'roof');
  b.box(0, base + h - 0.22, d / 2 + 0.3, main ? 5.5 : 3.6, 0.13, 0.14, '#d5b567', 'metal');
  for (let i = -1; i <= 1; i++) {
    b.box(i * (main ? 1.35 : 0.8), base + h - 0.85, d / 2 + 0.33, 0.1, 0.66, 0.09, '#e2c783', 'metal');
    b.box(i * (main ? 1.35 : 0.8), base + h - 0.78, d / 2 + 0.33, 0.49, 0.11, 0.09, '#e2c783', 'metal');
  }
  const roofY = base + h + 1.24;
  roof(b, { w: w + 7, d: d + 6, y: roofY, rise: main ? 5.8 : 4.5, style: main ? 'hip' : 'xie', gold: main });
  if (main) {
    const upperBase = roofY + 5.55;
    b.box(0, upperBase + 0.5, 0, w - 6, 1.5, d - 5, '#884630', 'clay');
    for (let x = -(w - 6) / 2; x <= (w - 6) / 2; x += 2.9) {
      for (const side of [-1, 1]) bracket(b, x, side * (d - 5) / 2, upperBase + 0.96, 0.65);
    }
    roof(b, { w: w + 0.6, d: d + 0.6, y: upperBase + 1.4, rise: 5.1, gold: true });
  }
}

function lion(b, x, z, mirror) {
  b.at(x, 0, z, 0, () => {
    foundation(b, 2.05, 2.55, 0.6, false);
    b.box(0, 1.14, -0.18, 1.14, 1.2, 1.33, '#bec1ae');
    for (const side of [-1, 1]) b.box(side * 0.49, 0.9, 0.58, 0.49, 0.66, 1.22, '#cdd0bc');
    b.box(0, 2.13, 0.46, 1.45, 1.04, 1.22, '#c0c5b3');
    b.box(0, 2.32, 1.11, 0.97, 0.52, 0.49, '#cdd0be');
    b.box(0, 2.04, 1.23, 0.8, 0.14, 0.15, '#707b70');
    for (const side of [-1, 1]) {
      b.box(side * 0.59, 2.72, 0.26, 0.4, 0.42, 0.48, '#adb9a7');
      b.box(side * 0.34, 2.45, 1.13, 0.15, 0.12, 0.075, '#536559');
      for (let i = 0; i < 3; i++) b.box(side * 0.75, 1.85 + i * 0.35, -0.02, 0.3, 0.38, 0.38, '#a4b09e');
    }
    b.box(mirror * 0.45, 0.97, 1.27, 0.72, 0.66, 0.7, '#a9b4a1');
    b.box(0.52, 1.24, -1.03, 0.31, 0.68, 0.5, '#abb4a2');
  });
}

function gate(b) {
  const base = 0.85, h = 6.8;
  foundation(b, 21, 8, base, true, 11, true);
  for (const x of [-8.7, -4.25, 4.25, 8.7]) for (const z of [-2.8, 2.8]) {
    pillar(b, x, z, base, h, 0.8);
    bracket(b, x, z, base + h, 0.84);
  }
  for (const x of [-6.45, 6.45]) {
    b.box(x, base + 2.65, -0.5, 3.3, 5.3, 0.55, '#9b442e', 'clay');
    for (let iy = 0; iy < 5; iy++) for (let ix = 0; ix < 4; ix++) {
      b.box(x - 1.08 + ix * 0.72, base + 0.85 + iy * 0.8, -0.17, 0.16, 0.16, 0.14, '#cbad62', 'metal');
    }
    lantern(b, x, base + h - 1.2, 3.8, 1.1);
  }
  b.box(0, base + h - 0.36, 2.83, 18.5, 0.8, 0.73, '#855538', 'wood');
  b.box(0, base + h + 0.56, 0, 19.2, 0.8, 7.1, '#844c32', 'wood');
  b.box(0, base + h - 0.15, 3.26, 4.6, 1.15, 0.18, '#31574a', 'roof');
  for (const x of [-1.25, 0, 1.25]) {
    b.box(x, base + h - 0.2, 3.4, 0.14, 0.67, 0.09, '#d2b677', 'metal');
    b.box(x, base + h - 0.26, 3.4, 0.58, 0.13, 0.09, '#d2b677', 'metal');
  }
  roof(b, { w: 26, d: 13.2, y: base + h + 1.3, rise: 3.5, style: 'xie' });
}

function tower(b, bell) {
  foundation(b, 11.7, 11.7, 1.4, true, 4.4);
  const base = 1.4, h = 4.5;
  for (const z of [-4, 4]) {
    for (const x of [-4, 0, 4]) {
      pillar(b, x, z, base, h, 0.67);
      bracket(b, x, z, base + h, 0.72);
    }
  }
  b.box(0, base + 2.1, -3.6, 7.5, 4.2, 0.48, '#a04933', 'clay');
  for (const side of [-1, 1]) {
    b.box(side * 3.6, base + 2.1, 0, 0.48, 4.2, 7.3, '#a54a32', 'clay');
  }
  windowPanel(b, 0, 2.3, base + 0.3, 5.7, 3.8);
  roof(b, { w: 14.1, d: 14.1, y: 7, rise: 2.3, style: 'pyramid', finial: false });
  const upper = 9.35;
  b.box(0, upper, 0, 7.35, 0.38, 7.35, '#8e5d3c', 'wood');
  for (const x of [-3, 3]) for (const z of [-3, 3]) {
    pillar(b, x, z, upper, 3.0, 0.55);
    bracket(b, x, z, upper + 3.0, 0.64);
  }
  for (const side of [-1, 1]) {
    b.box(0, upper + 0.9, side * 3.34, 7.15, 0.16, 0.23, '#b18952', 'wood');
    b.box(side * 3.34, upper + 0.9, 0, 0.23, 0.16, 7.15, '#b18952', 'wood');
    for (let i = -3; i <= 3; i++) {
      b.box(i, upper + 0.5, side * 3.34, 0.14, 0.8, 0.2, '#835339', 'wood');
      b.box(side * 3.34, upper + 0.5, i, 0.2, 0.8, 0.14, '#835339', 'wood');
    }
  }
  if (bell) {
    b.box(0, upper + 2.6, 0, 0.2, 0.6, 0.2, '#554c32', 'metal');
    for (let i = 0; i < 5; i++) {
      const s = 1.06 + i * 0.28;
      b.box(0, upper + 2.25 - i * 0.32, 0, s, 0.36, s, i % 2 ? '#887e4f' : '#948754', 'metal');
    }
    b.box(0, upper + 0.74, 0, 2.44, 0.24, 2.44, '#a18d51', 'metal');
  } else {
    b.box(0, upper + 1.55, 0, 2.55, 1.95, 1.9, '#794f31', 'wood');
    for (const side of [-1, 1]) {
      b.box(0, upper + 1.55, side * 1.02, 2.64, 2.02, 0.14, '#d1b984', 'wood');
      for (const x of [-1.3, 1.3]) b.box(x, upper + 1.55, side * 1.1, 0.14, 2.16, 0.16, '#a04b2c', 'clay');
      for (const y of [-0.98, 0.98]) b.box(0, upper + 1.55 + y, side * 1.1, 2.76, 0.13, 0.16, '#a04b2c', 'clay');
    }
    for (const x of [-1, 1]) b.box(x, upper + 0.35, 0, 0.38, 0.7, 2.4, '#694a34', 'wood');
  }
  roof(b, { w: 11.8, d: 11.8, y: upper + 4.1, rise: 3.2, style: 'pyramid' });
}

function perimeterWall(b, x, z, length, angle = 0) {
  b.at(x, 0, z, angle, () => {
    b.box(0, 0.46, 0, length, 0.9, 1.0, '#afaf96');
    for (let i = 0; i < Math.ceil(length / 1.15); i++) {
      const sx = length / Math.ceil(length / 1.15), px = -length / 2 + (i + 0.5) * sx;
      b.box(px, 1.86, 0, sx - 0.015, 1.9, 0.71, pick(P.red, px, 2), 'clay');
      for (const side of [-1, 1]) {
        b.box(px, 2.95, side * 0.41, sx, 0.29, 0.71, pick(P.jade, px, side), 'roof');
      }
      b.box(px, 3.21, 0, sx, 0.28, 0.6, '#66826b', 'roof');
    }
    for (let px = -length / 2; px <= length / 2 + 0.01; px += 6) {
      b.box(px, 1.82, 0, 1.1, 2.7, 1.07, '#a74831', 'clay');
      b.box(px, 3.28, 0, 1.43, 0.27, 1.42, '#557966', 'roof');
    }
  });
}

function pine(b, x, z, seed, size = 1, autumn = false) {
  b.at(x, 0, z, 0, () => {
    const h = (7 + hash(seed) * 2) * size;
    b.box(0, 0.23, 0, 2.4 * size, 0.46, 2.4 * size, '#929e7d');
    for (let y = 0.5; y < h; y += 0.72) b.box(0, y, 0, 0.65 * size, 0.76, 0.68 * size, pick(P.wood, seed, y), 'wood');
    const leaves = autumn ? P.autumn : P.leaves;
    for (let level = 0; level < 4; level++) {
      const radius = (3.25 - level * 0.62) * size;
      const yy = h * 0.43 + level * 1.4 * size;
      const shift = level % 2 ? 0.56 * size : -0.28 * size;
      b.box(shift, yy - 0.24, 0, radius * 1.5, 0.27, 0.35, '#725638', 'wood');
      for (let ix = -Math.ceil(radius / 0.9); ix <= Math.ceil(radius / 0.9); ix++) {
        for (let iz = -Math.ceil(radius / 0.9); iz <= Math.ceil(radius / 0.9); iz++) {
          const px = ix * 0.88, pz = iz * 0.88;
          if (Math.abs(px) + Math.abs(pz) > radius * 1.46 || Math.max(Math.abs(px), Math.abs(pz)) > radius) continue;
          b.box(px + shift, yy + (hash(ix + seed, level, iz) > 0.66 ? 0.4 : 0), pz,
            0.97, 0.85, 0.97, pick(leaves, ix + seed, level, iz), 'leaves');
        }
      }
    }
  });
}

function stoneLight(b, x, z) {
  b.box(x, 0.2, z, 1.6, 0.4, 1.6, '#c0c7b0');
  b.box(x, 1.03, z, 0.55, 1.25, 0.55, '#b1bda5');
  b.box(x, 1.75, z, 1.28, 0.24, 1.28, '#cbd0b7');
  b.box(x, 2.17, z, 0.8, 0.62, 0.8, '#e7c386', 'glow');
  for (const dx of [-0.39, 0.39]) for (const dz of [-0.39, 0.39]) b.box(x + dx, 2.17, z + dz, 0.16, 0.72, 0.16, '#a8b59d');
  b.box(x, 2.65, z, 1.64, 0.25, 1.64, '#8ba18a');
  b.box(x, 2.88, z, 1.06, 0.22, 1.06, '#a9baa1');
  b.box(x, 3.1, z, 0.46, 0.23, 0.46, '#bac7ad');
}

function pond(b, x, z) {
  b.box(x, 0.18, z, 7.3, 0.22, 9.5, '#537d72', 'water');
  for (const side of [-1, 1]) {
    b.box(x + side * 3.85, 0.37, z, 0.57, 0.7, 10.6, '#c7c8ad');
    b.box(x, 0.37, z + side * 5.0, 8.27, 0.7, 0.58, '#c7c8ad');
    for (let i = -3; i <= 3; i++) {
      b.box(x + i, 0.78, z + side * 5.0, 0.96, 0.13, 0.69, pick(P.stone, i, x, side));
    }
  }
  for (let i = 0; i < 8; i++) {
    const px = x + (hash(i, x) - 0.5) * 5.5, pz = z + (hash(i, z, 1) - 0.5) * 7;
    b.box(px, 0.32, pz, 0.85, 0.08, 0.82, '#79925a', 'water');
    if (i % 3 === 0) {
      b.box(px, 0.53, pz, 0.33, 0.35, 0.33, '#e1b09a', 'clay');
      b.box(px, 0.74, pz, 0.19, 0.12, 0.19, '#ecd2b0', 'clay');
    }
  }
  for (let i = 0; i < 6; i++) {
    b.box(x - 2.2 + hash(i, x, z) * 4.4, 0.302, z - 3.9 + i * 1.55, 1.7, 0.025, 0.06, '#9fb4a1', 'water');
  }
}

function incense(b) {
  const z = 0;
  foundation(b, 4.0, 3.4, 0.4, false);
  for (const x of [-1.0, 1.0]) for (const dz of [-0.75, 0.75]) b.box(x, 0.84, z + dz, 0.36, 1.0, 0.36, '#526a55', 'metal');
  b.box(0, 1.43, z, 2.8, 1.13, 2.25, '#64795c', 'metal');
  b.box(0, 2.03, z, 3.12, 0.2, 2.54, '#ad9855', 'metal');
  for (const side of [-1, 1]) {
    b.box(side * 1.76, 1.89, z, 0.3, 1.25, 0.45, '#5e7356', 'metal');
    b.box(side * 1.44, 2.52, z, 0.94, 0.23, 0.45, '#8d8951', 'metal');
  }
  for (const x of [-0.6, 0, 0.6]) b.box(x, 2.51, z, 0.08, 0.86, 0.08, '#926345', 'wood');
}

export function createWorld(scene) {
  const b = new VoxelBatch();
  // Cutaway block terrain establishes a firm, flat ground datum for every stair.
  b.box(0, -1.5, -2, 98, 2.8, 106, '#877957', 'ground');
  b.box(0, -0.27, -2, 98.3, 0.52, 106.3, '#748764', 'ground');
  b.box(0, -2.9, -2, 99.4, 0.55, 107.4, '#8c8063', 'ground');
  for (let x = -47; x <= 47; x += 2.0) for (const z of [-55.06, 51.06]) {
    b.box(x, -1.65, z, 1.97, 1.62, 0.13, pick(['#8d8060', '#958768', '#82765b'], x, 3, z), 'ground');
    b.box(x, -0.7, z, 1.97, 0.38, 0.17, '#a2926c', 'ground');
  }
  for (let z = -54; z <= 50; z += 2) for (const x of [-49.06, 49.06]) {
    b.box(x, -1.65, z, 0.13, 1.62, 1.97, pick(['#8d8060', '#958768', '#82765b'], x, 2, z), 'ground');
    b.box(x, -0.7, z, 0.17, 0.38, 1.97, '#a2926c', 'ground');
  }

  // North is -Z. The entry and ceremonial route remain on x=0.
  paving(b, 0, 10, 37, 40, 2.15);
  paving(b, 0, 3, 9.6, 89, 1.55, true, 0.035);
  paving(b, 0, -1, 75, 5.2, 1.8, false, 0.018);
  paving(b, 0, 32, 75, 5.8, 1.9, false, 0.018);
  paving(b, 0, -39, 77, 4.8, 2.0, false, 0.022);
  for (const side of [-1, 1]) paving(b, side * 37.4, -5.5, 4.3, 64, 1.8, false, 0.01);
  for (const side of [-1, 1]) {
    b.box(side * 18.8, 0.21, 10, 0.5, 0.24, 40, '#adb39a');
    b.box(side * 8.0, 0.19, 45.0, 5.9, 0.24, 8, '#92a17e', 'ground');
    for (let i = 0; i < 16; i++) {
      b.box(side * (5.8 + (i % 4) * 1.4), 0.4, 41.6 + Math.floor(i / 4) * 1.8,
        0.4, 0.45, 0.4, pick(P.leaves, i, side), 'leaves');
    }
  }
  perimeterWall(b, -42, -1, 82, Math.PI / 2);
  perimeterWall(b, 42, -1, 82, Math.PI / 2);
  perimeterWall(b, 0, -42, 84);
  perimeterWall(b, -26.3, 40, 31.4);
  perimeterWall(b, 26.3, 40, 31.4);

  b.at(0, 0, -24, 0, () => hall(b, { w: 29, d: 18, base: 2.1, h: 8.0, bays: 7, main: true }));
  b.at(-27, 0, -3, Math.PI / 2, () => hall(b, { w: 22, d: 11.5, base: 1.2, h: 5.5, bays: 5 }));
  b.at(27, 0, -3, -Math.PI / 2, () => hall(b, { w: 22, d: 11.5, base: 1.2, h: 5.5, bays: 5 }));
  b.at(0, 0, 37, 0, () => gate(b));
  b.at(-27, 0, 24, 0, () => tower(b, true));
  b.at(27, 0, 24, 0, () => tower(b, false));
  lion(b, -7.1, 44.1, -1);
  lion(b, 7.1, 44.1, 1);
  lion(b, -9.2, -10.4, -1);
  lion(b, 9.2, -10.4, 1);
  pond(b, -11.1, 10.3);
  pond(b, 11.1, 10.3);
  b.at(0, 0, -3, 0, () => incense(b));

  for (const side of [-1, 1]) {
    for (const z of [-34, -21, 3, 34]) pine(b, side * 37, z, z + 80, z === 34 ? 0.84 : 1);
    pine(b, side * 34.8, 14.0, 47, 0.85, true);
    pine(b, side * 20.0, -36.8, 36, 0.68);
    for (const z of [-7.0, 0, 22.0, 32.5]) stoneLight(b, side * (z === -7 ? 16.4 : 17.0), z);
    for (let i = 0; i < 90; i++) {
      const px = side * (43.4 + hash(i, side) * 4.2), pz = -49.2 + hash(i, 5, side) * 96;
      b.box(px, 0.1, pz, 0.65 + hash(i) * 0.5, 0.16, 0.8,
        pick(['#7f9168', '#819466', '#6c835c'], i, px, pz), 'ground');
      if (i % 7 === 0) {
        b.box(px, 0.4, pz, 0.1, 0.42, 0.1, '#668150', 'leaves');
        b.box(px, 0.64, pz, 0.22, 0.18, 0.22, '#dbbc7c', 'clay');
      }
    }
    // Low trimmed shrubs along the wall, clear of every path and stair.
    for (let i = 0; i < 9; i++) {
      b.box(side * (3 + i * 3.8), 0.4, -45.8, 2.0, 0.8, 1.6, pick(P.leaves, i, side), 'leaves');
    }
  }
  const stats = b.finish(scene);
  return { ...stats, buildingCount: 6,
    buildings: [
      { name: '主殿', position: [0, 8, -24], roof: '重檐庑殿顶' },
      { name: '西配殿', position: [-27, 4, -3], roof: '歇山顶' },
      { name: '东配殿', position: [27, 4, -3], roof: '歇山顶' },
      { name: '山门', position: [0, 4, 37], roof: '歇山顶' },
      { name: '钟楼', position: [-27, 8, 24], roof: '四角攒尖顶' },
      { name: '鼓楼', position: [27, 8, 24], roof: '四角攒尖顶' },
    ],
  };
}
