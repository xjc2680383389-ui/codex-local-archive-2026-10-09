import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { createWorld } from './world.js';
import './style.css';

const canvas = document.querySelector('#scene');
const loading = document.querySelector('#loading');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let renderer, controls, rafId = 0;

function showError(message) {
  loading.hidden = true;
  document.querySelector('#error-message').textContent = message;
  document.querySelector('#error-panel').hidden = false;
  document.querySelectorAll('.view-controls button, .light-switch button').forEach(button => { button.disabled = true; });
}

try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  // All shadow-casting objects and the sun are static between light changes.
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#e4e8da');
  scene.fog = new THREE.Fog('#e4e8da', 210, 430);
  const camera = new THREE.PerspectiveCamera(36, window.innerWidth / window.innerHeight, 0.5, 1500);
  controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.dampingFactor = 0.065;
  controls.minDistance = 24;
  controls.maxDistance = 850;
  controls.minPolarAngle = 0.13;
  controls.maxPolarAngle = Math.PI / 2.14;
  controls.zoomSpeed = 0.8;
  controls.rotateSpeed = 0.64;
  controls.panSpeed = 0.65;
  controls.autoRotateSpeed = 0.8;
  controls.target.set(0, 3, -1);

  const hemisphere = new THREE.HemisphereLight('#f8f3d7', '#718367', 2.25);
  scene.add(hemisphere);
  const sun = new THREE.DirectionalLight('#fff0c7', 3.25);
  sun.position.set(-65, 100, 55);
  sun.target.position.set(0, 0, -5);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -82, right: 82, top: 83, bottom: -83, near: 10, far: 260 });
  sun.shadow.bias = -0.00025;
  sun.shadow.normalBias = 0.14;
  sun.shadow.radius = 2.0;
  scene.add(sun, sun.target);
  const fill = new THREE.DirectionalLight('#b9d8d0', 0.45);
  fill.position.set(60, 45, -60);
  scene.add(fill);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(1200, 1200),
    new THREE.MeshStandardMaterial({ color: '#c4ceb6', roughness: 1 }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -3.22;
  ground.receiveShadow = true;
  scene.add(ground);
  const world = createWorld(scene);

  const views = {
    overview: { position: [125, 109, 151], target: [0, 3, -2], title: '山院全景', description: '重檐庑殿 · 歇山 · 四角攒尖' },
    axis: { position: [0, 46, 131], target: [0, 5, -4], title: '循中轴而入', description: '山门 → 前院 → 莲池 → 主殿' },
    hall: { position: [42, 36, 44], target: [0, 12, -22], title: '重檐主殿', description: '金瓦飞檐 · 层叠斗拱 · 朱柱木窗' },
    plan: { position: [0, 166, 56], target: [0, 0, -2], title: '一轴六殿', description: '左右配殿相望，钟鼓分列山门两侧' },
  };
  let currentView = 'overview', currentLight = 'morning', flight = null;
  let isInteracting = false, lastFrame = performance.now();
  let frames = [], frameCounter = 0;
  const stats = { ready: false, buildingCount: world.buildingCount, voxelCount: world.voxelCount,
    batches: world.batches, buildings: world.buildings, view: currentView, light: currentLight,
    fps: 0, frameP95Ms: 0, sampleCount: 0, renderCalls: 0, triangles: 0,
    pixelRatio: renderer.getPixelRatio(), webgl: renderer.getContext() instanceof WebGL2RenderingContext ? 2 : 1,
    errors: [] };
  // A read-only snapshot for reproducible local rendering / performance checks.
  Object.defineProperty(window, '__YUNQUE__', { value: Object.freeze({
    getStats: () => ({ ...stats, camera: camera.position.toArray(), target: controls.target.toArray(),
      autoRotate: controls.autoRotate, size: [window.innerWidth, window.innerHeight] }),
  }) });

  function fitPosition(view) {
    const pos = new THREE.Vector3(...view.position);
    const target = new THREE.Vector3(...view.target);
    const aspect = camera.aspect;
    const wideScene = currentView === 'overview' || currentView === 'plan';
    const factor = Math.max(1, (wideScene ? 1.2 : 0.82) / aspect);
    pos.sub(target).multiplyScalar(factor).add(target);
    if (aspect < 0.9 && wideScene) target.y = 7;
    return { pos, target };
  }

  function setView(key, immediate = false) {
    currentView = key;
    stats.view = key;
    const view = views[key], { pos, target } = fitPosition(view);
    document.querySelectorAll('[data-view]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.view === key));
    });
    document.querySelector('#view-title').textContent = view.title;
    document.querySelector('#view-description').textContent = view.description;
    document.body.classList.toggle('immersive', key === 'hall' || key === 'axis');
    if (immediate || reducedMotion) {
      flight = null;
      camera.position.copy(pos);
      controls.target.copy(target);
      controls.update();
    } else {
      flight = { start: performance.now(), from: camera.position.clone(), to: pos,
        fromTarget: controls.target.clone(), toTarget: target };
    }
  }

  function setTour(active) {
    controls.autoRotate = active;
    document.querySelector('#tour-toggle').setAttribute('aria-pressed', String(active));
    document.querySelector('#tour-toggle span').textContent = active ? '暂停' : '环游';
  }

  function setLight(mode) {
    currentLight = mode;
    stats.light = mode;
    const evening = mode === 'evening';
    document.body.classList.toggle('evening', evening);
    scene.background.set(evening ? '#768d89' : '#e4e8da');
    scene.fog.color.copy(scene.background);
    ground.material.color.set(evening ? '#84977b' : '#c4ceb6');
    hemisphere.color.set(evening ? '#9dafce' : '#f8f3d7');
    hemisphere.groundColor.set(evening ? '#5b6953' : '#718367');
    hemisphere.intensity = evening ? 1.5 : 2.25;
    sun.color.set(evening ? '#ffc184' : '#fff0c7');
    sun.intensity = evening ? 2.8 : 3.25;
    sun.position.set(...(evening ? [-65, 43, -42] : [-65, 100, 55]));
    fill.color.set(evening ? '#8ea4bf' : '#b9d8d0');
    fill.intensity = evening ? 0.35 : 0.45;
    renderer.toneMappingExposure = evening ? 1.03 : 1.18;
    world.glowMaterials.forEach(material => { material.emissiveIntensity = evening ? 2.3 : 0.45; });
    renderer.shadowMap.needsUpdate = true;
    document.querySelectorAll('[data-light]').forEach(button => {
      button.setAttribute('aria-pressed', String(button.dataset.light === mode));
    });
  }

  document.querySelectorAll('[data-view]').forEach(button => {
    button.addEventListener('click', () => setView(button.dataset.view));
  });
  document.querySelectorAll('[data-light]').forEach(button => {
    button.addEventListener('click', () => setLight(button.dataset.light));
  });
  document.querySelector('#tour-toggle').addEventListener('click', () => setTour(!controls.autoRotate));
  const helpToggle = document.querySelector('#help-toggle'), helpPanel = document.querySelector('#help-panel');
  helpToggle.addEventListener('click', () => {
    helpPanel.hidden = !helpPanel.hidden;
    helpToggle.setAttribute('aria-expanded', String(!helpPanel.hidden));
  });
  document.addEventListener('keydown', event => {
    if (event.code === 'Escape') { helpPanel.hidden = true; helpToggle.setAttribute('aria-expanded', 'false'); return; }
    if (event.target.matches('input, textarea, select, [contenteditable="true"]')) return;
    if (event.code === 'Space' && !event.target.matches('button')) { event.preventDefault(); setTour(!controls.autoRotate); }
    if (event.code === 'KeyR') { setTour(false); setView('overview'); }
  });
  controls.addEventListener('start', () => {
    isInteracting = true;
    flight = null;
    setTour(false);
  });
  controls.addEventListener('end', () => { isInteracting = false; });
  canvas.addEventListener('webglcontextlost', event => {
    event.preventDefault();
    cancelAnimationFrame(rafId);
    stats.errors.push('WebGL context lost');
    showError('浏览器图形上下文已中断，请重新加载页面。');
  });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    if (!isInteracting) setView(currentView, true);
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) cancelAnimationFrame(rafId);
    else { lastFrame = performance.now(); frames = []; rafId = requestAnimationFrame(render); }
  });

  function render(now) {
    const delta = Math.min((now - lastFrame) / 1000, 0.1);
    const interval = now - lastFrame;
    lastFrame = now;
    if (flight) {
      const t = Math.min((now - flight.start) / 1300, 1);
      const ease = t * t * (3 - 2 * t);
      camera.position.lerpVectors(flight.from, flight.to, ease);
      controls.target.lerpVectors(flight.fromTarget, flight.toTarget, ease);
      if (t === 1) flight = null;
    }
    controls.update(delta);
    const distance = camera.position.distanceTo(controls.target);
    scene.fog.near = distance + 65;
    scene.fog.far = distance + 420;
    renderer.render(scene, camera);
    if (interval > 0 && stats.ready) {
      frames.push(interval);
      if (frames.length > 360) frames.shift();
      if (++frameCounter % 30 === 0) {
        const sorted = [...frames].sort((a, b) => a - b);
        stats.fps = Math.round(10000 / (frames.reduce((a, b) => a + b, 0) / frames.length)) / 10;
        stats.frameP95Ms = Math.round(sorted[Math.floor(sorted.length * 0.95)] * 10) / 10;
        stats.sampleCount = frames.length;
      }
    }
    stats.renderCalls = renderer.info.render.calls;
    stats.triangles = renderer.info.render.triangles;
    rafId = requestAnimationFrame(render);
  }

  setView('overview', true);
  rafId = requestAnimationFrame(now => {
    render(now);
    stats.ready = true;
    loading.classList.add('ready');
    setTimeout(() => { loading.hidden = true; }, reducedMotion ? 0 : 500);
  });
} catch (error) {
  console.error('Yunque scene initialization failed:', error);
  showError('无法初始化三维场景。请使用支持 WebGL 2 的新版 Chrome、Edge 或 Firefox，并确认浏览器已开启硬件加速。');
}
