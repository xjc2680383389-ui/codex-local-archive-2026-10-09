import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

// Bundle the already-built entry into one portable HTML without extra plugins.
const root = resolve(import.meta.dirname, '..');
let html = await readFile(resolve(root, 'dist/index.html'), 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/g)];
const styles = [...html.matchAll(/<link\b[^>]*\brel="stylesheet"[^>]*>/g)];
if (scripts.length !== 1 || styles.length !== 1) {
  throw new Error('Expected exactly one built JS entry and one stylesheet.');
}
const cssPath = styles[0][0].match(/href="([^"]+)"/)[1];
const scriptPath = scripts[0][1];
const [js, css, icon, license] = await Promise.all([
  readFile(resolve(root, 'dist', scriptPath.replace(/^\//, '')), 'utf8'),
  readFile(resolve(root, 'dist', cssPath.replace(/^\//, '')), 'utf8'),
  readFile(resolve(root, 'public/favicon.svg'), 'utf8'),
  readFile(resolve(root, 'node_modules/three/LICENSE'), 'utf8'),
]);
html = html.replace(scripts[0][0], '');
html = html.replace(styles[0][0], () => `<style>${css.replace(/<\/style/gi, '<\\/style')}</style>`);
html = html.replace(/<link\b[^>]*\brel="icon"[^>]*>/,
  () => `<link rel="icon" href="data:image/svg+xml;base64,${Buffer.from(icon).toString('base64')}">`);
// Function replacements preserve literal $&, $`, and $' inside bundled code.
html = html.replace('</body>', () => `<script type="module">${js.replace(/<\/script/gi, '<\\/script')}</script>\n</body>`);
html += `\n<!-- Three.js license:\n${license.replace(/--/g, '- -')}\n-->\n`;
await writeFile(resolve(root, 'dist/云阙山院.html'), html);
await writeFile(resolve(root, '..', '云阙山院.html'), html);
await writeFile(resolve(root, 'THIRD_PARTY_NOTICES.txt'), `Runtime dependency: Three.js 0.186.1\nhttps://threejs.org/\n\n${license}\n\nBuild tool: Vite 8.3.2 (MIT), build-time only.\n`);
console.log(`Standalone HTML created (${(Buffer.byteLength(html) / 1024).toFixed(0)} KiB).`);
